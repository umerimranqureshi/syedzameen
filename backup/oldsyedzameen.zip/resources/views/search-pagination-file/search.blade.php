<form id="main-search-form" method="GET" action="{{route('property.search')}}"
    class="adbanced-form-two amenities-list border-top-1-gray">
    <input name="search" value="search" type="hidden">
    <div class="row">
        <div class="form-group col-lg-3 col-md-6 col-6 pt-15">
            <div class="select-wrapper position-relative">
                <select id="city" name="city" class="select form-control">
                    <option value="null">Select City</option>

                    @foreach ($cities as $city)

                    <option @isset($old_city) {{$old_city==$city->city?"selected":''}} @endisset
                        value="{{$city->city}}">
                        {{$city->city}}</option>

                    @endforeach

                </select>
            </div>
        </div>



        <div class="form-group col-lg-3 col-md-6 col-6 pt-15">
            <div class="select-wrapper position-relative">
                <select id="location" name="city_area" class="select form-control">

                    <option value="null">Select Location</option>


                </select>
            </div>
        </div>




        <div class="form-group col-lg-3 col-md-6 col-6 pt-15">
            <div class="select-wrapper position-relative">
                <select name="purpose" class="select form-control">
                    <option @isset($old_purpose){{ $old_purpose=="null"?"selected":''}}@endisset value="null">Purpose
                    </option>

                    <option @isset($old_purpose) {{$old_purpose=="sale"?"selected":''}}@endisset value="sale">
                        Sale</option>


                    <option @isset($old_purpose) {{$old_purpose=="rent"?"selected":''}}@endisset value="rent">Rent
                    </option>
                </select>
            </div>
        </div>

        <div class="form-group col-lg-3 col-md-6 col-6 pt-15">
            <div class="select-wrapper position-relative">
                <select id="property_type" name="property_type" class="select form-control">
                    <option @isset($old_property_type) {{$old_property_type=="null"?"selected":''}}@endisset
                        value="null">Property Type
                    </option>
                    <option @isset($old_property_type) {{$old_property_type=="residential"?"selected":''}}@endisset
                        value="residential">
                        Residential</option>
                    <option @isset($old_property_type) {{$old_property_type=="commercial"?"selected":''}}@endisset
                        value="commercial">
                        Commercial</option>
                </select>
            </div>
        </div>

        <div class="form-group col-lg-3 col-md-6 col-6 pt-15">
            <div class="select-wrapper position-relative">
                @php

                if(isset($old_property_sub_type)){
                $OPT=$old_property_sub_type;
                }
                @endphp

                <select id="sub_type" name="sub_type" class="select form-control">
                    <option @isset($OPT) {{$OPT=="null"?"selected":''}} @endisset value="null">Property
                        Sub-Type</option>
                    <option @isset($OPT) {{$OPT=="home"?"selected":''}} @endisset value="home">Home
                    </option>
                    <option @isset($OPT) {{$OPT=="upper_portion"?"selected":''}} @endisset value="upper_portion">Upper
                        Portion
                    </option>
                    <option @isset($OPT) {{$OPT=="lower_portion"?"selected":''}} @endisset value="lower_portion">Lower
                        Portion
                    </option>
                    <option @isset($OPT) {{$OPT=="residential_plot"?"selected":''}}@endisset value="residential_plot">
                        Residential Plot</option>
                    <option @isset($OPT) {{$OPT=="commercial_plot"?"selected":''}}@endisset value="commercial_plot">
                        Commercial
                        Plot</option>
                    <option @isset($OPT) {{$OPT=="flat"?"selected":''}} @endisset value="flat">Flat
                    </option>
                    <option @isset($OPT) {{$OPT=="office"?"selected":''}}@endisset value="office">Office
                    </option>
                    <option @isset($OPT) {{$OPT=="shop"?"selected":''}}@endisset value="shop">Shop
                    </option>
                    <option @isset($OPT) {{$OPT=="building"?"selected":''}}@endisset value="building">
                        Building</option>
                </select>
            </div>
        </div>

        <div class="form-group col-lg-3 col-md-6 col-6 pt-15">
            <div class="select-wrapper position-relative">
                <select name="beds" class="select form-control has-val">
                    <option @isset($old_beds) {{$old_beds=="null"?"selected":''}}@endisset value="null">
                        Beds</option>
                    <option @isset($old_beds){{$old_beds=="1"?"selected":''}}@endisset value="1">One
                    </option>
                    <option @isset($old_beds) {{$old_beds=="2"?"selected":''}}@endisset value="2">Two
                    </option>
                    <option @isset($old_beds){{$old_beds=="3"?"selected":''}}@endisset value="3">Three
                    </option>
                    <option @isset($old_beds){{$old_beds=="4"?"selected":''}}@endisset value="4">Four
                    </option>
                </select>
            </div>
        </div>

        <div class="form-group mb-0 pb-15 col-lg-3 col-md-6 col-6">
            <div class="price_range">
                <div class="price-filter">
                    <span><input id="filter_sqft" type="text" name="area" value="{{$old_area ?? "0;200"}}" /></span>
                </div>
            </div>
        </div>


        <div class="form-group mb-0 pb-15 col-lg-3 col-md-6 col-6">
            <div class="price_range">
                <div class="price-filter">
                    <span class="price-slider">
                        <input class="filter_price" type="text" name="price" value="{{$old_price ?? "0;90000000"}}" />
                    </span>
                </div>
            </div>
        </div>

        <div class="form-group mb-0 pb-15 col-lg-3 col-md-6 col-6">
            <button class="p-5" style="background-color: orange" type="submit">Search!</button>
        </div>



    </div>
</form>