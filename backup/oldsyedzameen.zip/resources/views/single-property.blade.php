@inject('helper', 'App\Http\Controllers\helper')
@extends('layout')

@section('header')

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
	integrity="sha256-4+XzXVhsDmqanXGHaHvgh1gMQKX40OUvDEBTu8JcmNs=" crossorigin="anonymous"></script>
<style>
	.icon-size {
		font-size: 20px;
		color: #fd9834;
	}
</style>

@endsection
@section('body')


<!-- Page Banner Start
==================================================================-->
<div class="page-banner overlay-black" style="padding: 150px 0">
	<div class="container h-100">
		<div class="row h-100 align-items-center">
			<div class="col-lg-12">
				<h1 class="page-banner-title color-primary">Enhanced Living Experience</h1>
				<div class="text-area w-50 mt-15 color-white">
					<p>Interior of volumes, space, air, proportion, with certain light and mood. These interiors are
						meant to last forever.</p>
				</div>
			</div>
		</div>
	</div>
</div>
<div class="bg-secondary">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-lg-12">
				<nav aria-label="breadcrumb">
					<ol class="breadcrumb m-0 py-15 px-0 bg-transparent hover-white-primary">
						<li class="breadcrumb-item"><a href="{{route('home')}}">Home</a></li>


						<li class="breadcrumb-item active" aria-current="page">Single Property</li>
					</ol>
				</nav>
			</div>
		</div>
	</div>
</div>
<!-- Page Banner End
==================================================================-->
<!-- Single Property Start
==================================================================-->
<section>
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-lg-12">
				<div class="mb-30">
					<div class="row">
						<div class="col-md-12 col-lg-8">
							<div class="single-property position-relative">
								<span
									class="bg-secondary color-white z-index-1 px-15 py-5 mr-20">{{$post->propertyCate->purpose}}
									@if ($post->post_boaster=='hot'||$post->post_boaster=='superhot')

									<i style="color:{{($post->post_boaster=='superhot')? 'rgba(238, 14, 14, 0.932)' :'rgba(255, 0, 179, 0.877)' }} ;
									font-size:17px" class="fa fa-fire"> </i>
									@endif
								</span>
								@if ($post->post_boaster=='superhot')
								<span class="color-white z-index-1 px-15 py-5 mr-20"
									style="background-color: rgba(255, 0, 0, 0.788)">super Hot</span>
								@endif
								@if ($post->post_boaster=='hot')
								<span class="color-white z-index-1 px-15 py-5 mr-20"
									style="background-color: rgba(255, 0, 119, 0.774)">Hot</span>
								@endif
								<strong class="color-primary f-20">PKR {{$post->price}}
									{{$post->propertyCate->purpose=="rent"?"Monthly":"" }} </strong>
								<h3 class="color-secondary mt-15">{{$post->property_title}}</h3>
								<span class="address icon-primary f-14 mt-5"><i class="fa fa-map-marker"></i>
									{{$post->cityAndArea->area ." ,". $post->cityAndArea->city }}</span>
								<ul class="property-features icon-primary d-table f-14 mt-15">
									<li><i style="font-size: 20px" class="fa fa-area-chart"></i>{{$post->land_area}}
										Marla</li>
									<li><i style="font-size: 20px" class="fa fa-bed"></i>{{$post->bedrooms}} Bedrooms
									</li>
									<li><i style="font-size: 20px" class="fa fa-bath"></i>{{$post->bathrooms}} Bathrooms
									</li>
									<li><i style="font-size: 20px" class="fa fa-car"></i> Garage</li>
								</ul>
							</div>
						</div>
						<div class="col-md-12 col-lg-4">
							<div class="thumbnail-content float-right">
								<ul class="hover-option icon-white z-index-1 position-relative mt-md-30"
									style="opacity: 1; top: 0; right: 0;">
									<li>

										<a data-toggle="tooltip" data-placement="top" @if($favPost->isNotEmpty())
											@foreach ($favPost as $fav)

											@if($fav->user_id==Auth::id() && $fav->post_id==$post->id)
											class="fav-heart bg-danger"
											title="remove wishlist"
											@else
											class="fav-heart "
											title="wishlist"
											@endif

											@endforeach
											@endif
											@if($favPost->isEmpty() && Auth::check())
											class="fav-heart "
											title="wishlist"
											@endif

											href="{{route('favPost',['id'=>$post->id])}}" >
											<i class="fa fa-heart-o " aria-hidden="true"> </i></a>


									</li>

								</ul>
								<!-- Nav tabs -->
								{{-- <ul class="nav nav-tabs border-0 float-right navbar-tab-view mt-15 sm-mt-0"
									role="tablist" style="line-height: 20px;">
									<li class="nav-item">
										<a class="nav-link active" id="home-tab" data-toggle="tab" href="#home"
											role="tab" aria-controls="home" aria-selected="true"><i
												class="fa fa-file-image-o" aria-hidden="true"></i></a>
									</li>
									<li class="nav-item">
										<a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile"
											role="tab" aria-controls="profile" aria-selected="false"><i
												class="flaticon-location"></i></a>
									</li>
									<li class="nav-item">
										<a class="nav-link" id="messages-tab" data-toggle="tab" href="#messages"
											role="tab" aria-controls="messages" aria-selected="false"><i
												class="flaticon-street-view"></i></a>
									</li>
								</ul> --}}
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid">
		<div class="row d-flow-root">
			<div class="product-slider">
				<div class="tab-content">
					<div class="tab-pane active position-relative" id="home" role="tabpanel" aria-labelledby="home-tab">
						<div class="service-images owl-carousel slide-1 dot-on-slider">

							@if($post->postImages->isEmpty())
							<img style="height: 600px" src="{{asset('houseLog.jpg')}}" alt="image">

							@else

							@foreach ($post->postImages as $image)

							<img style="height: 600px" src='{{asset("propertyImages/$image->img_path")}}' alt="image">

							@endforeach

							@endif
						</div>
					</div>
					<div class="tab-pane" id="profile" role="tabpanel" aria-labelledby="profile-tab">
						<div id="map" class="canvas" style="height: 600px"></div>
					</div>
					<div class="tab-pane" id="messages" role="tabpanel" aria-labelledby="messages-tab">
						<div class="mapimageview"><iframe
								src="https://www.google.com/maps/embed?pb=!4v1599036304356!6m8!1m7!1sqKj5Ao7cdLkLmIAAieQWgw!2m2!1d-37.78266616894371!2d145.0232453320753!3f99.89449149743196!4f-13.159907315623357!5f0.7820865974627469"
								height="600" style="border:0;" allowfullscreen="" aria-hidden="false"
								tabindex="0"></iframe></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-lg-8">
				<div class="text-area mt-50">
					<h3 class="color-secondary line-bottom pb-15 mb-20">Description</h3>
					<p>{{$post->description}}.</p>

					<div class="agent-more-details color-secondary-a">
						<a class="color-secondary position-relative plus-minus my-15 pl-15 d-block"
							data-toggle="collapse" href="#multiCollapse1" role="button" aria-expanded="false"
							aria-controls="multiCollapse1">More Details</a>
						<div class="collapse" id="multiCollapse1">


						</div>
					</div>
				</div>
				<div class="border-top-1-gray py-30">
					<h3 class="color-secondary line-bottom pb-15 mb-20">Property Details</h3>
					<div class="row">
						<div class="col-md-12 col-lg-6">
							<ul class="list-by-tag">
								@if($post->bedrooms || $post->bathrooms)
								<li><i style="font-size: 20px" class="fa fa-bed icon-size"></i> Bedrooms
									<span>{{$post->bedrooms}}</span></li>


								{{-- <li>Orienten : <span>East</span></li> --}}
								<li><i style="font-size: 20px" class="fa fa-bath icon-size"></i> Bathrooms :
									<span>{{$post->bathrooms}}</span></li>
								{{-- <li>Type : <span>Private House</span></li> --}}
								@endif
								<li><i style="font-size: 20px" class="fa fa-user icon-size"></i> contact person name :
									<span>{{$post->contact_person_name}}</span></li>



							</ul>
						</div>
						<div class="col-md-12 col-lg-6">
							<ul class="list-by-tag hover-secondery-primary">
								<li><i class="fa fa-plus-square icon-size"></i> Land Area :
									<span>{{$post->land_area." ". $post->unit." Marla" }} </span></li>

								<li><i style="font-size: 20px" class="fa fa-car icon-size"></i> Garage : <span>1</span>
								</li>
								<li><i style="font-size: 20px" class="fa fa-clock-o icon-size"></i> Post Timings :
									<span>{{$post->created_at->diffForHumans()}}</span></li>

								{{-- <li>Plot size : <span>300x200x300</span></li> --}}
								{{-- <li>Kitchens : <span>2</span></li> --}}
							</ul>
						</div>
						{{-- <div class="col-md-12 col-lg-6">


							<ul class="list-by-tag hover-secondery-primary">
								<li><i style="font-size: 20px" class="fa fa-map-marker icon-size"></i> Address : <span>{{$post->address}}</span>
						</li>

						</ul>
					</div> --}}
				</div>
			</div>

			<!-------------------------------------Amenities---------------------------->
			<div class="border-top-1-gray py-30">
				<h3 class="color-secondary line-bottom pb-15 mb-20">Amenities</h3>
				<div class="row">
					<div class="col-md-12 col-lg-12">
						<ul class="single-property-amenities icon-primary my-20">

							@foreach ($helper::stringSeperatedByCommaToArray($post->amenities) as $amenitie)

							<li><i class="fa fa-check-square" aria-hidden="true"></i> {{$amenitie}}</li>

							@endforeach

						</ul>
					</div>
				</div>
			</div>
			<!--//-----------------------------------Amenities end-----------------//----------->

			<!---------------------------------------Video Div---------------------------------->

			<div class="border-top-1-gray py-30">
				<h3 class="color-secondary line-bottom pb-15 mb-20">Property Video</h3>
				<div class="property-video bg-img-3 position-relative">

					<iframe id="iframe_youtube" style="position: relative; height: 100%; width: 100%;" src=""
						frameborder="0"></iframe>


					{{-- <a data-fancybox="" class="video-popup xy-center bg-primary color-white"
						href="javascript:void(0)"><i class="fa fa-play"
							aria-hidden="true"></i></a> --}}
					{{-- <div class="loader xy-center">
						<div class="loader-inner ball-scale-multiple">
							<div></div>
							<div></div>
							<div></div>
						</div>
					</div> --}}
				</div>
			</div>

			<!------//------------------------------Video Div end------------------------//---------->

		</div>



		<div class="col-md-12 col-lg-4">
			<!--------------------------- Message Box Start--------------------------->
			<div class="sidebar-widget bg-white mt-50 shadow py-40 px-30">


				<h3 class="color-secondary line-bottom pb-15 mb-20">Send Enquiry message</h3>


				<form id="sendMessageForm" class="mt-30">

					<div class="row">

						<div class="form-group col-md-12">
							<input type="hidden" name="message[]"
								value=" <a href='{{url('single/pageadd/').'/'.$post->id}}'>Property Title : {{$post->property_title}}</a><br>">

							<textarea class="form-control bg-gray" rows="4" name="message[]"
								placeholder="Type Your Message"></textarea>

							<input type="hidden" name="reciver_id" value="{{$post->user->id}}" id="">

							<input type="hidden" name="sender_id" value="{{Auth::id()}}" id="">

							<p id="success_msg" class="text-success"></p>

						</div>


						<div class="col-lg-12"><button type="submit"
								class="btn btn-primary w-100 {{Auth::id() == $post->user->id?'disabled':''}}">Send
								Message</button></div>
					</div>
				</form>

			</div>

			<!--------------------------- Message Box  end--------------------------->



			<div class="sidebar-widget bg-white mt-50 shadow py-40 px-30">
				<h3 class="color-secondary line-bottom pb-15 mb-20">Latest Properties</h3>
				<div class="owl-carousel slide-1 owl-dots-none">

					@foreach ($latestPost as $postL)
					<div class="property-item">
						<div class="property-img position-relative overflow-hidden overlay-secondary-4">
							<img src="{{$postL->postImagesOne?asset('propertyImages/'.$postL->postImagesOne->img_path):asset('houseLog.jpg') }}"
								alt="image" style="height: 200px">
							<span class="thum-category category-1 bg-secondary color-white z-index-1 px-15">New
								@if ($post->post_boaster=='hot'||$post->post_boaster=='superhot')

								<i style="color:{{($post->post_boaster=='superhot')? 'rgba(238, 14, 14, 0.932)' :'rgba(255, 0, 179, 0.877)' }} ;
									font-size:17px" class="fa fa-fire"> </i>
								@endif

							</span>
							<ul class="hover-option position-absolute icon-white z-index-1">
								<li>
									<a data-toggle="tooltip" data-placement="top" @foreach ($favAllPost as $fav)
										@if($fav->user_id==Auth::id() && $postL->favPostUser->count()>0 &&
										$fav->post_id==$postL->id)
										class="bg-danger fav-heart"
										title="remove wishlist"


										@endif

										@endforeach
										@if($post->favUserPost==null)
										class="fav-heart"
										title="wishlist"
										@endif

										href="{{route('favPost',['id'=>$postL->id])}}"><i class="fa fa-heart-o"
											aria-hidden="true"></i></a>
								</li>


							</ul>
							<div class="meta-property icon-primary color-white z-index-1">
								<ul>
									<li><i class="fa fa-calendar"></i>{{$postL->created_at}}</li>
									<li><i class="fa fa-user"></i> {{$postL->user->name}}</li>
								</ul>
							</div>
						</div>
						<div class="property-content bg-white pt-30 pb-50">
							<a class="color-secondary mb-5" href="{{route('singlePage',['id'=>$postL->id])}}">
								<h5>{{$postL->property_title}}</h5>
							</a>
							<span class="address icon-primary f-14"><i
									class="fa fa-map-marker"></i>{{$postL->address}}</span>
							<ul class="about-property list-half icon-primary d-table f-14 mb-30 mt-20">
								<li><i class="fa fa-plus-square "></i>{{$postL->land_area." ". $postL->unit }}</li>
								<li><i class="fa fa-bed"></i>{{$postL->bedrooms}} bedrooms</li>
								<li><i class="fa fa-bath"></i>{{$postL->bathrooms}} bathrooms</li>
								<li><i class="fa fa-home"></i>1 Garage</li>
							</ul>
							<div class="property-cost color-white list-half w-100">
								<ul>
									<li>{{$postL->propertyCate->purpose}}</li>
									<li>{{" ".$postL->price}}
										<sub>{{$postL->propertyCate->purpose=="rent"?'Monthly':''}}</sub>
									</li>
								</ul>
							</div>
						</div>
					</div>
					@endforeach

				</div>
			</div>


		</div>


	</div>
	</div>
</section>
<!-- Single Property End
==================================================================-->
<!--  Partners and Subscribe Form Start
==================================================================-->
<div class="patner-subscribe">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-lg-12">
				<div class="bg-white shadow py-80">
					<div class="row">
						<div class="col-md-12 col-lg-6 px-60 border-right">
							<div class="side-title pb-30">
								<span class="small-title color-primary position-relative line-primary">Partners</span>
								<h2 class="title mb-20 color-secondary">Our Popular Fellows!</h2>
								<p>These are our popular fellows. if you want to become a fellow then <a
										href="{{route('contactUs')}}">contact us</a>
								</p>
							</div>
							<div class="owl-carousel partners mt-30">
								<img src="{{asset('login-logo.png')}}" alt="Image not found!">
								<img src="{{asset('syedEstate Real logo.png')}}" alt="">
								{{-- <img src="" alt=""> --}}
							</div>
						</div>
						<div class="col-md-12 col-lg-6 px-60">
							<div class="side-title pb-30 text-right mt-md-50">
								<span
									class="small-title color-primary position-relative line-right-primary">Newsletter</span>
								<h2 class="title mb-20 color-secondary">Get Update Now!</h2>
								<p>Get daily news of properties in the market by our newsletter features just subscribe
									us</p>
							</div>
							<form class="news-letter bg-gray mt-30">
								<div id="subscribe-message" style="margin-bottom:2px;font-size:20px"></div>
								<div class="form-group position-relative" id="subscribe-hide">
									<input class="form-control" type="text" name="email" placeholder="Subscribe"
										id="subscribe-input">
									<button class="bg-gray color-secondary" id="btn-subscribe"><i
											class="fa fa-paper-plane"></i></button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--  Partners and Subscribe Form
==================================================================-->
<!-- jquery Links
==================================================================-->

<!----------------------------------------Javascript starts---------------------------------------->

<script src="{{asset('jsComman/comman.js')}}"></script>


<script type="text/javascript">

	function embedYoutubeURL() {
         $str = "{{$post->video_link}}";
         $res = $str.split("=");
         $embeddedUrl = "https://www.youtube.com/embed/"+$res[1];
		$("#iframe_youtube").attr("src",$embeddedUrl);
    }


	$(document).ready(() => {
		embedYoutubeURL();

		$(document).on('click', '.fav-heart', function (e) {
			e.preventDefault();

			var data = $(this).attr('href');

			var self = this;
			// Save the reference
			$.ajax({
				method: 'get',
				url: data,
				data: data,
				async: true,

				success: () => {
					console.log("success");

				},
				complete: (data) => {
					if (data.responseJSON.message == "remove") {
						self.classList.remove("bg-danger");

						setTimeout(()=>{
							$(this).tooltip('hide').attr('data-original-title', 'wishlist');
						},500);
						console.log("class removes");
					} else if ((data.responseJSON.message == "success")) {
						self.classList.add("bg-danger");
						setTimeout(()=>{
							$(this).tooltip('hide').attr('data-original-title', 'remove wishlist');
						},500);

					}else{
						console.log("no classs applied");
					}
				}

			});

		});

		$("#subscribe-input").on("input", function () {
			// Print entered value in a div box

			if (!$(this).val()) {

				$('#subscribe-message').text('email required');
				$('#subscribe-message').css('color', 'red');

			} else {
				$('#subscribe-message').text('');
			}

		});


		$(document).on('click', '#btn-subscribe', function (e) {
			e.preventDefault();
			if ($('#subscribe-input').val() == '') {
				$('#subscribe-message').text('email required');
				$('#subscribe-message').css('color', 'red');
			} else {


				$('#subscribe-hide').hide();
				$('#subscribe-message').text('Thanks for subscribing us');
				$('#subscribe-message').addClass('color-primary');

			}
		});


	});


	var auth_user = "{{Auth::id()}}";
	var post_user_id = "{{$post->user->id}}";

	$("#sendMessageForm").submit(function (e) {
		e.preventDefault();
		console.log(auth_user, post_user_id);
		if (auth_user == post_user_id) {

			return false;

		}

		$.ajax({
			url: "{{route('inbox.store')}}",
			headers: {
				'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
			},
			async: false,
			method: "POST",
			data: $(this).serialize(),
			success: function (res) {

				$("#success_msg").text("Message Has Been Send");
				$('#success_msg').fadeIn().delay(2000).fadeOut('slow');


			}

			,

		});

		$(this).trigger("reset");


	});










</script>
@endsection