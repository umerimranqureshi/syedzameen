<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\AddToFavorite;
use App\Models\Agencie;
use App\Models\Fresh;
use App\Models\User;
use App\Models\PostImage;
use App\Models\PropertyCategorie;
use App\Models\Post;
use App\Models\RequestAnAgent;
use App\Models\UserAccount;
use App\Models\UserCoinRequest;
use App\Models\UserPostReq;
use Image;
use Intervention\Image\File;
//use DB;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;

class SecondMain extends Controller
{
    public function addToFav(Request $request)
    {
        // dd($request->id);
        if (Auth::check()) {
            $fav = AddToFavorite::where('post_id', $request->id)->where('user_id', Auth::id())->get();

            if ($fav->count() > 0) {
                AddToFavorite::where('post_id', $request->id)->where('user_id', Auth::id())->delete();

                return ['message' => 'remove'];
            } else {

                AddToFavorite::create([
                    'user_id' => auth()->user()->id,
                    'post_id' => $request->id,
                ]);
                return ['message' => 'success'];
            }
        } else {

            return redirect('/login')->with('loginFirst', 'Login here');
        }
    }

    public function showFavPost()
    {


        // dd($favPOst->userFavPost->first()->post_id);

        $fav = AddToFavorite::with(['post.propertyCate', 'post.agencies', 'image'])->where('user_id', Auth::id())->get();

        // dd($fav);

        // dd($fav);
        return view('adminPanel.favPost', ['fav' => $fav]);
    }

    public function userMoreInfo()
    {

        return view('adminPanel.usermoreinfo');
    }

    public function submitMoreInfo(Request $req)
    {


        if (Auth()->check()) {


            $validatedData = $req->validate([
                'address' => ['required'],
                'cnic' => ['required'],
            ]);

            if ($validatedData) {
                $user = Auth::user();

                $user->address = $req->address;
                $user->cnic = $req->cnic;
                $user->role = 3;


                $user->save();

                return redirect('/');
            }
        }
    }

    public function adminFeaturePost()
    {

        $cities = DB::table("city_and_areas")->distinct()->get("city");

        return view('adminPanel.postAdd', compact("cities"));
    }

    public function adminPostAdd(Request $req)
    {

        // /dd($req->all());


        $req->validateWithBag("addPostError", [

            "property_title" => "required",
            "description" => "required",
            "price" => "required",
            "land_area" => "required",
            "contact_person_name" => "required",
            "mobile_number" => "required|integer",
            "email" => "email",
            "address" => "required"


        ]);

        $propertyAllFields = PropertyCategorie::where("purpose", $req->purpose)
            ->where("property_type", $req->property_type)
            ->where("property_sub_type", $req->sub_type)
            ->first();

        ///////converting every unit into marla ///////

        switch ($req->unit) {

            case "kanal":
                $marla = $req->land_area * 20;
                break;

            case "square_feet":
                $marla = $req->land_area / 272;
                break;

            case "square_yards":
                $marla = $req->land_area / 30.25;
                break;


            case "marla":
                $marla = $req->land_area;
                break;
        }

        ///////converting every unit into marla end ///////


        $postCreated = Post::create([
            "property_title" => $req->property_title,
            "description" => $req->description,
            "price" => $req->price,
            "land_area" => $marla,
            "bedrooms" => $req->bedroom,
            "bathrooms" => $req->bathroom,
            "video_link" => $req->video_link,
            "amenities" => $req->amenities,

            "city_area_id" => $req->city_area,
            "address" => $req->address,
            "contact_person_name" => $req->contact_person_name,
            "mobile_number" => $req->mobile_number,
            "mobile2_number" => $req->mobile2_number,
            "email" => $req->email,
            "disable" => '0',
            "admin_post" => 1,
            "user_id" => Auth::id(),
            "property_categorie_id" => $propertyAllFields->id,

        ]);



        ///////////saving image///////////////////
        if ($req->image != null) {
            $i = 0;
            while (count($req->image) > $i) {
                // returns Intervention\Image\Image
                $path = $req->image[$i]->getRealPath();
                $resize = Image::make($path)->resize(468, 304)->encode('jpg');
                // dd($resize);
                // calculate md5 hash of encoded image
                $hash = md5($resize->__toString());

                // use hash as a name
                $path = "propertyImages/{$hash}.jpeg";


                // save it locally to ~/public/images/{$hash}.jpg
                $resize->save(public_path($path));

                // $url = "/images/{$hash}.jpg"
                $url = "{$hash}.jpeg";

                PostImage::create([
                    "img_name" => $url,
                    "post_id" => $postCreated->id,
                    "img_path" => $url

                ]);
                $i++;
            }
        }

        return back()->with("success", "Post succesfully inserted");
    }
    /* public function addToRequestAgent(Request $request)
    {


        $prev = RequestAnAgent::where('user_id', Auth::id())->where('post_id', $request->id)->get();

        if ($prev->count() > 0) {
            return redirect('/');
        }

        $request->validate([

            "message" => "required",
        ]);


        RequestAnAgent::create([
            "message" => $request->message,
            "user_id" => Auth::id(),
            "post_id" => $request->id
        ]);

        $postOfUser = Post::with('user')->where('id', $request->id)->get();

        return view('requestAnAgent', compact('postOfUser'));
    } */
    /* public function showAllRequestToAgents()
    {

        $allReqToAgents = RequestAnAgent::with('post.user')->where('user_id', Auth::id())->get();
        //  dd($allReqToAgents);
        return view('adminPanel.requestToAgents', compact('allReqToAgents'));
    } */

    /* public function ShowClientrequest()
    {


        $reqClient = Post::with('requestOfClients.user')->where('user_id', Auth::id())->get();

        // foreach($reqClient as $client){
        //     dd($client->requestOfClients->count());

        // }
        // $reqClient->map(function ($post) {
        //        dd($post);
        //      });


        return view('adminPanel.clientrequest', compact('reqClient'));
    } */

    public function showAgencies()
    {

        $latestPost = Post::with(["postImagesOne", "postViews", "propertyCate", "agencies", "favPostUser", "user"])->where('admin_post', null)->latest()->limit(6)->get();
        // dd($latestPost);
        $featureAgencies = Agencie::with('user.post')->paginate('2');
        //   dd($featureAgencies);
        $favPost = AddToFavorite::where('user_id', Auth::id())->get();
        $cities = DB::table("city_and_areas")->distinct()->get("city");

        return view('agncies', compact('featureAgencies', 'latestPost', "cities", "favPost"));
    }

    public function favPostApi()
    {

        return [
            'fav' => AddToFavorite::where('user_id', Auth::id())->get(),
            'allPost' => Post::with(["postImagesOne", "postViews", "propertyCate", "agencies", "favPostUser", "user"])->where('admin_post', null)->latest()->limit(6)->get()
        ];
    }
    public function contactUs()
    {
        return view('contact');
    }


    //admin disable enable
    public function deleteDisableView()
    {

        if (Auth::user()->role == 1) {
            $allPost = Post::with(["postImages", "postViews", "propertyCate", "cityAndArea"])->get();
            //    dd($allPost);
            return view('adminPanel.DeleteDisable', compact('allPost'));
        } else {
            abort(400);
        }
    }
    public function adminDeletePost($id)
    {
        if (Auth::user()->role == 1) {
            Post::with(["postImagesOne", "postViews", "propertyCate", "agencies", "favPostUser", "cityAndArea"])->where('id', $id)->delete();
            return redirect()->back();
        } else {
            abort(400);
        }
    }
    public function adminDisableEnable($id)
    {

        if (Auth::user()->role == 1) {
            $enable = Post::where('id', $id)->where('disable', '1')->get();
            if ($enable->isEmpty()) {
                Post::where('id', $id)->update(['disable' => 1]);
                return redirect()->back();
            } else {
                post::where('id', $id)->update(['disable' => 0]);
                return redirect()->back();
            }
        } else {
            abort(400);
        }
    }










    //coins modules
    public function freshesView()
    {
        $rates = Fresh::latest()->get();

        return view('superAdmin.addFreshRatesView', compact('rates'));
    }

    public function addFreshesRates(Request $req)
    {

        $req->validate(
            [
                'coin_rate' => 'required',
                'hot_post_rate' => 'required',
                'super_hot_post_rate' => 'required',
            ]
        );
        Fresh::create(
            [
                'coin_rates' => $req->coin_rate,
                'hot_rates' => $req->hot_post_rate,
                'superhot_rates' => $req->super_hot_post_rate
            ]
        );
        return redirect()->back()->with('message', 'Rates Successfully Added');
    }
    public function editFreshView(Request $req, $id)
    {
        $updateRate = Fresh::where('id', $id)->first();
        return view('superAdmin.addFreshRatesView', compact('updateRate'));
    }
    public function updateFreshRate(Request $req, $id)
    {

        $rates = Fresh::find($id);
        $rates->coin_rates = $req->coin_rate;
        $rates->hot_rates = $req->hot_post_rate;
        $rates->superhot_rates = $req->super_hot_post_rate;
        $rates->save();
        return redirect('/freshes/rates')->with('message', 'Rate updated');
    }
    public function pricingView()
    {
        $freshRates = Fresh::latest()->first();

        return view('adminPanel.Pricing', compact('freshRates'));
    }
    public function BuyCoinView()
    {
        $freshRates = Fresh::latest()->first();

        return view('adminPanel.buyCoins', compact('freshRates'));
    }
    public function addToRequestCoin(Request $req)
    {

        $req->validate(
            [
                'coins' => 'required',
            ]
        );
        $freshes = Fresh::with('userCoinsReq')->latest()->first();
        if ($freshes) {
            $userAcc = UserCoinRequest::where('user_id', Auth::id())->latest()->first();

            if (is_null($userAcc)) {
                $newAcc = new UserCoinRequest();
                $newAcc->user_id = Auth::id();
                $newAcc->coins = $req->coins;
                $newAcc->allow_coins = 'no';
                $newAcc->rupees = $freshes->coin_rates * $req->coins;
                $newAcc->freshes_id = $freshes->id;
                $newAcc->save();
                return redirect()->back();
            } elseif ($userAcc->allow_coins == 'no') {
                return redirect()->back()->with('buyCoins', 'Please Wait For Your Last Request To Approved');
            } elseif ($userAcc->allow_coins == 'yes') {
                $newAcc = new UserCoinRequest();
                $newAcc->user_id = Auth::id();
                $newAcc->coins = $req->coins;
                $newAcc->allow_coins = 'no';
                $newAcc->rupees = $freshes->coin_rates * $req->coins;
                $newAcc->freshes_id = $freshes->id;
                $newAcc->save();
                return redirect()->back();
            }
        } else {
            return redirect()->back();
        }
    }

    ///user approval for coin request
    public function allCoinRequest()
    {
        $coinReq = UserCoinRequest::with('User')->where('allow_coins', 'no')->get();

        return view('superAdmin.coinRequests', compact('coinReq'));
    }
    public function approveCoinRequest($user, $coins, $id)
    {


        $userAcc = UserAccount::where('user_id', $user)->first();
        //if already exist
        if (is_null($userAcc)) {
            $newAcc = new UserAccount();
            $newAcc->user_id = $user;
            $newAcc->coins = $coins;

            $newAcc->save();
        } else {
            $userAcc->coins += $coins;

            $userAcc->save();
        }



        $reqApproved = UserCoinRequest::where('id', $id)->first();

        if ($reqApproved->allow_coins == 'no') {
            $reqApproved->allow_coins = 'yes';
            $reqApproved->save();
            return redirect()->back();
        }
    }

    public function showApprovedCoins()
    {
        $approvedCoins = UserCoinRequest::with('User', 'freshe')->where('allow_coins', 'yes')->get();
        // dd($approvedCoins);
        return  view('superAdmin.coinRequests', compact('approvedCoins'));
    }

    public function boastPost($post_id, $cat)
    {

        $currentRates = Fresh::latest()->first();



        if (!is_null($currentRates)) {

            if (Auth::user()->Account) {

                if (Auth::user()->Account->coins >= $currentRates->{$cat . '_rates'}) {
                    //if have enough coins

                    $newPostReq = new UserPostReq();
                    $newPostReq->user_id = Auth::id();
                    $newPostReq->post_id = $post_id;
                    $newPostReq->boast_cat = $cat;
                    $newPostReq->coins = $currentRates->{$cat . '_rates'};
                    $newPostReq->rupees = $currentRates->{$cat . '_rates'} * $currentRates->coin_rates;
                    $newPostReq->freshes_id = $currentRates->id;
                    $newPostReq->save();

                    $post = Post::find($post_id);
                    $post->post_boaster = $cat;
                    $post->save();

                    $m = Auth::user()->Account;
                    $m->coins -= $currentRates->{$cat . '_rates'};
                    $m->save();
                    return redirect()->back()->with('message', 'Your Property Has Been Boasted');
                } else {
                    return redirect()
                        ->route('CoinBuy')
                        ->with('buyCoins', 'You Dont Have Enough Coins. Please Buy Coins To Boast Your Post');
                }
            } else {
                return redirect('/coin/buy')->with('buyCoins', 'Please buy some coins');
            }
        } else {
            return redirect()->back()->with('message', 'Admin is not set pricing yet');
        }
    }

    //show request to admin
    public function allPostrequests()
    {
        $postReq = UserPostReq::with('user', 'post')->get();

        return view('superAdmin.postRequests', compact('postReq'));
    }

    // public function allowBoasterPost($post_id,$boaster_id,$boaster_cat,$coins,$rupees,$user_id)
    // {

    //     $boaster=UserPostReq::where('id',$boaster_id)->first();
    //     if(!is_null($boaster)){
    //         $boaster->allow_boast='yes';
    //         $boaster->save();
    //     }
    //     $post=Post::where('id',$post_id)->first();
    //     if(!is_null($post)){
    //         $post->post_boaster=$boaster_cat;
    //         $post->save();

    //     }
    //     $deduct=UserAccount::where('user_id',$user_id)->first();

    //     $deduct->coins -= $coins;
    //     $deduct->RS -=$rupees;
    //     $deduct->save();
    //     return redirect()->back();
    // }

    // public function allApprovedPost()
    // {
    //     $approvePost=UserPostReq::with('user','post')->get();
    //     return view('superAdmin.postRequests',compact('approvePost'));
    // }


    public function singlePageAgency($id)
    {
        $singleAgency = Agencie::with('user.post')->where('id', $id)->first();

        $favPost = AddToFavorite::where('user_id', Auth::id())->get();
        return view('singleAgency', compact('singleAgency', 'favPost'));
    }
}
