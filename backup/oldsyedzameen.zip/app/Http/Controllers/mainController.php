<?php

namespace App\Http\Controllers;


use Illuminate\Contracts\Pagination\Paginator;
use App\Models\AddToFavorite;
use App\Models\Agencie;
use App\Models\blog;
use App\Models\blogImage;
use App\Models\forgotPassword;
use App\Models\Lahore;
use App\Models\PhoneNumberVarification;
use Illuminate\Http\Request;
use App\Models\Post;
use App\Models\PostImage;
use App\Models\PostViews;
use Illuminate\Support\MessageBag;
use App\Models\PropertyCategorie;
use App\Models\RequestAnAgent;
use App\Models\User;
use App\Models\CityAndArea;
use App\Models\Fresh;

use Illuminate\Pagination\LengthAwarePaginator;
use Illuminate\Pagination\Paginator as PaginationPaginator;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Session;
use PhpParser\Node\Stmt\Return_;

class mainController extends Controller
{


    public function indexView()
    {
        // dd(User::where('google_id','10635473357604182573')->first());
        $latestPostLimit = 6;

        $latestPost = Post::with(["postImagesOne", "postViews", "propertyCate", "agencies", "favPostUser", "user"])->where('admin_post', null)->where('disable', '0')->latest()->limit($latestPostLimit)->reorder('post_boaster', 'DESC')->get();


        ////////post added by admin fetch in view////////

        $adminPost = Post::with(["postImages", "postViews", "propertyCate", "agencies"])->where('admin_post', 1)->get();

        // $favPost = AddToFavorite::where('user_id', Auth::id())->get();
        $favPost='';


        $featureAgencies = Agencie::with('user')->get();

        $special = Post::with(["postImagesOne", "postViews", "propertyCate", "agencies", "favPostUser", "user"])->where('admin_post', null)->where('disable', '0')->latest()->limit(11)->reorder('post_boaster', 'DESC')->get();
        //    dd($special);
        $specialPost = $this->specialPostSort($special, $latestPostLimit);
        // dd($specialPost);
        $allPostNumber = count(Post::all());
        $allAgentNumber = count(Agencie::all());
        //////reading data from json file
        $jsonFile = Storage::disk("public_main")->get("json/data.json");
        $phpObj = json_decode($jsonFile, true);
        $allSoldProperty = $phpObj["allSoldPostNum"];

        return view('index', compact('latestPost', 'adminPost', 'featureAgencies', 'favPost', "allSoldProperty", "allPostNumber", "allAgentNumber", "specialPost"));
    }
    private function specialPostSort($posts, $limit)
    {
        $data = [];
        for ($i = $limit; $i < count($posts); $i++) {
            $data[] = $posts[$i];
        }
        return $data;
    }

    public function rentResidentialView()
    {
        $allRCP = $this->universalForRentAndSale("rent", "residential");

        $favPost = AddToFavorite::where('user_id', Auth::id())->get();

        $cities = DB::table("city_and_areas")->distinct()->get("city");



        return view('rent.residential', compact("allRCP", "cities", "favPost"));
    }

    public function rentCommercialView()
    {
        ///allRentCommercialProperty
        $allRCP = $this->universalForRentAndSale("rent", "commercial");
        $cities = DB::table("city_and_areas")->distinct()->get("city");
        $favPost = AddToFavorite::where('user_id', Auth::id())->get();

        // dd($allRCP);

        return view('rent.commercial', compact('allRCP', "cities", "favPost"));
    }



    public function saleResidentialView()
    {

        $allRCP = $this->universalForRentAndSale("sale", "residential");
        $cities = DB::table("city_and_areas")->distinct()->get("city");
        $favPost = AddToFavorite::where('user_id', Auth::id())->get();

        // foreach($allRCP as $post){
        //     dd($post->property_title);
        // }

        return view('sale.residential', compact("allRCP", "cities", "favPost"));
    }

    public function saleCommercialView()
    {

        $allRCP = $this->universalForRentAndSale("sale", "commercial");
        $cities = DB::table("city_and_areas")->distinct()->get("city");
        $favPost = AddToFavorite::where('user_id', Auth::id())->get();
        // dd($allRCP);
        return view('sale.commercial', compact('allRCP', "cities", "favPost"));
    }


    public function postAddView()
    {


        $cities = DB::table("city_and_areas")->distinct()->get("city");

        //dd("s");

        return view('adminPanel.postAdd', compact("cities"));
    }

    public function postAdd(Request $req)
    {


        // dd($req->purpose, $req->property_type, $req->sub_type);

        $req->validateWithBag("addPostError", [

            "property_title" => "required|max:50",
            "description" => "required",
            "price" => "required",
            "land_area" => "required",
            "contact_person_name" => "required|max:20",
            "mobile_number" => "required|integer",
            "email" => "email",
            "address" => "required"

        ]);


        //dd($req->purpose,$req->property_type,$req->sub_type);
        $propertyAllFields = PropertyCategorie::where("purpose", $req->purpose)
            ->where("property_type", $req->property_type)
            ->where("property_sub_type", $req->sub_type)
            ->first();
        //dd($propertyAllFields->id);
        ///////converting every unit into marla ///////

        switch ($req->unit) {

            case "kanal":
                $marla = $req->land_area * 20;
                break;

            case "square_feet":
                $marla = $req->land_area / 272;
                break;

            case "square_yards":
                $marla = $req->land_area / 30.25;
                break;


            case "marla":
                $marla = $req->land_area;
                break;
        }

        ///////converting every unit into marla end ///////

        $postCreated = Post::create([
            "property_title" => $req->property_title,
            "description" => $req->description,
            "price" => $req->price,
            "land_area" => $marla,
            "bedrooms" => $req->bedroom,
            "bathrooms" => $req->bathroom,
            "video_link" => $req->video_link,
            "amenities" => $req->amenities,

            "city_area_id" => $req->city_area,
            "address" => $req->address,
            "contact_person_name" => $req->contact_person_name,
            "mobile_number" => $req->mobile_number,
            "mobile2_number" => $req->mobile2_number,
            "email" => $req->email,
            "user_id" => Auth::id(),
            "property_categorie_id" => $propertyAllFields->id,
            "disable" => '0',

        ]);

        ///////////saving image///////////////////

        if ($req->image != null) {
            $i = 0;
            while (count($req->image) > $i) {

                $imageName = Storage::disk("public_main")->put('propertyImages', $req->image[$i]);
                $imagePath = substr($imageName, 15);

                PostImage::create([
                    "img_name" => $imagePath,
                    "post_id" => $postCreated->id,
                    "img_path" => $imagePath

                ]);

                $i++;
            }
        }
        return back()->with("success", "Post succesfully inserted");
    }

    public function editProfileView()
    {
        $user = Auth::user();

        return view('adminPanel.editprofile', ['user' => $user]);
    }

    public function editProfileSubmit(Request $request)
    {
        if (Auth()->check()) {

            $validatedData = $request->validate([
                'new_user_name' => ['required'],
                'new_email' => ['required'],
                /* 'old_password' => ['required'], */
                /* 'new_password' => ['required'], */
                'new_mobile_number' => 'required',
            ]);

            if ($validatedData) {

                if (!Hash::check("@*!@#$@#!%^@-!@!+_@)#*$(!@@#!", auth()->user()->password)) {
                    if (!Hash::check($request->old_password, auth()->user()->password)) {

                        return redirect()->back()->with('passNotMatch', 'old password not matched');
                    }
                }

                $user = User::where("id", Auth::id())->first();

                if ($request->new_password != null) {
                    $newPassword = Hash::make($request->new_password);
                    $user->password = $newPassword;
                }



                $user->name = $request->new_user_name;
                $user->email = $request->new_email;


                if ($user->mobile_number != $request->new_mobile_number) {
                    $checkNewPhoneExists = User::where("mobile_number", $request->new_mobile_number)->first();
                    //dd($checkNewPhoneExists);
                    if (empty($checkNewPhoneExists)) {

                        $user->mobile_number = $request->new_mobile_number;

                        $userPhone = $user->getPhone()->first();

                        if ($userPhone) {
                            $userPhone->verified = 0;
                            $userPhone->save();
                        }
                    } else {


                        return back()->with("msg", "Phone Already exists");
                    }
                }

                //$user->role = '3';
                $user->save();


                return redirect()->back();
            }
        }
    }

    public function getAreasAccordingCity($city)
    {
        $areas = CityAndArea::where("city", $city)->get();

        return $areas;
    }

    public function uploadUserProfile(Request $request)
    {


        if ($request->hasFile('image')) {



            $filename = $request->image->getClientOriginalName();

            if (auth()->user()->img_path) {

                unlink(auth()->user()->img_path);
            }

            $randomName = rand();
            //store new file in project
            $request->image->storeAs('profilePic', $randomName . $filename, 'public_main');

            $user = Auth::user();
            $user->img_path = 'profilePic/' . $randomName . $filename;
            $user->save();

            return redirect()->back();
        } else {
            return redirect()->back()->with('message', 'please choose an image');
        }
    }
    public function dashboredView()
    {
        $post = Post::with('postImagesOne')->where('user_id', Auth::id())->get();

        $postViews = PostViews::with('post')->where('user_id', Auth::id())->first();

        $soldPost = Post::where('user_id', Auth::id())->where('sold', 1)->get();

        $favPost = AddToFavorite::where('user_id', Auth::id())->get();
        $likes = AddToFavorite::where('user_id', '!=', Auth::id())->get();

        $hotPost=$post->where('post_boaster','hot');

        $superHot=$post->where('post_boaster','superhot');

        $soldHot=$hotPost->where('sold',1);
        $soldSuperHot=$superHot->where('sold',1);

        $latestfivePost=Post::with('postImagesOne')->where('user_id',Auth::id())->latest()->limit(6)->get();

        $boasted=Post::with('postImagesOne')->where('post_boaster','superhot')->orWhere('post_boaster','hot')->get();


        return view("adminPanel.dashbored", compact(
            'post',
           'soldPost',
           'postViews',
           'favPost',
            'likes',
            'hotPost',
            'superHot',
            'soldHot',
            'soldSuperHot',
            'latestfivePost',
            'boasted'
        ));
    }

    public function editPostView($id)
    {
        ///with eager loading .. loaded relationship which is define in model
        $userPost = Post::with(["postImages", "cityAndArea", "propertyCate"])
            ->where("id", $id)
            ->where("user_id", Auth::id())
            ->first();


        //dd($userPost);

        $cities = DB::table("city_and_areas")->distinct()->get("city");


        return view("adminPanel.editPost", compact("userPost", "cities"));


        return redirect(url('/dashbored'));
    }


    public function allPostView()
    {
        // $userPostCheck = Post::where("user_id", Auth::id())->first();
        //dd($userPostCheck);

        $userAllPost = Post::select(
            "posts.*",
            "property_categories.purpose",
            "property_categories.property_type",
            "property_categories.property_sub_type",
            DB::raw("(select post_images.img_path from post_images where post_id = posts.id limit 1) as img")
        )->with('postViews')

            ->join("property_categories", "posts.property_categorie_id", "property_categories.id")
            ->where("posts.user_id", Auth::id())

            ->get();

        $rates = Fresh::latest()->first();

        return view('adminPanel.postTable', compact("userAllPost", "rates"));
    }


    public function deletePost($id)
    {


        $post = Post::where('id', $id)->with("postImages")->first();

        if (!empty($post)) {

            $post->delete();
        }

        return redirect()->back();
    }




    public function editPost(Request $req, $id)
    {
        $post = Post::where("user_id", Auth::id())->where("id", $id)->first();
        //dd($post);
        if (!empty($post)) {

            $req->validateWithBag("addPostError", [
                "address" => "required",
                "property_title" => "required",
                "address" => "required",
                "property_title" => "required",
                "description" => "required",
                "price" => "required",
                "land_area" => "required",
                "contact_person_name" => "required",
                "mobile_number" => "required|integer",
                "email" => "email",



            ]);





            $propertyAllFields = PropertyCategorie::where("purpose", $req->purpose)
                ->where("property_type", $req->property_type)
                ->where("property_sub_type", $req->sub_type)
                ->first();



            ///////converting every unit into marla ///////

            switch ($req->unit) {

                case "kanal":
                    $marla = $req->land_area * 20;
                    break;

                case "square_feet":
                    $marla = $req->land_area / 272;
                    break;

                case "square_yards":
                    $marla = $req->land_area / 30.25;
                    break;


                case "marla":
                    $marla = $req->land_area;
                    break;
            }




            //dd($marla);
            ///////converting every unit into marla end ///////






            $post->property_title = $req->property_title;
            $post->description = $req->description;
            $post->price = $req->price;
            $post->land_area = $marla;
            $post->bedrooms = $req->bedroom;
            $post->bathrooms = $req->bathroom;

            $post->address = $req->address;

            $post->city_area_id = $req->city_area;

            $post->contact_person_name = $req->contact_person_name;
            $post->mobile_number = $req->mobile_number;
            $post->mobile2_number = $req->mobile2_number;
            $post->email = $req->email;

            $post->video_link = $req->video_link;
            $post->amenities = $req->amenities;
            $post->property_categorie_id = $propertyAllFields->id;
            $post->disable = 0;
            $post->save();

            ///////////saving image and deleting old image///////////////////
            if ($req->image != null) {

                ///getting old images
                $postImages = PostImage::where("post_id", $post->id)->get();

                ///deleting old images
                foreach ($postImages as $image) {

                    unlink(public_path("propertyImages/" . $image->img_path));
                    $image->delete();
                }


                $i = 0;
                while (count($req->image) > $i) {

                    $imageName = Storage::disk("public_main")->put('propertyImages', $req->image[$i]);
                    $imagePath = substr($imageName, 15);

                    PostImage::create([
                        "img_name" => $imagePath,
                        "post_id" => $post->id,
                        "img_path" => $imagePath

                    ]);

                    $i++;
                }
            }
            return redirect()->back()->with("msg", "post edited succesfully");
        }


        return redirect()->back()->with("msg", "their is some kind of network issue");
    }


    public function singlePageAddView($id)
    {

        $latestPost = Post::with(["postImagesOne", "postViews", "propertyCate", "agencies", "favPostUser", "user"])->where('admin_post', null)->latest()->limit(6)->get();

        ////////add views to post////////


        $this->addPostViews(Auth::id(), $id);

        ////////add views to post end////////

        $post = Post::where("id", $id)
            ->with(["cityAndArea", "postImages", 'user', "postViews", "propertyCate", "favPostUser"])
            ->first();

        if (!$post) {
            abort(404);
        }

        //for message form
        $alreadyHaveReq = RequestAnAgent::with('post')->where('user_id', Auth::id())->where('post_id', $id)->get();
        // dd($post->id);
        $favPost = AddToFavorite::where('user_id', Auth::id())->where('post_id', $post->id)->get();
        $favAllPost = AddToFavorite::where('user_id', Auth::id())->get();
        // dd($favPost);
        // foreach($favPost as $fav){
        //     if($fav->post_id == $post->id){
        //        dd($favPost);
        //     }
        // }

        return view('single-property', compact('post', 'alreadyHaveReq', 'favPost', 'latestPost', 'favAllPost'));
    }


    public function universalForRentAndSale($purpose, $type)
    {

        $allpost = Post::with(["propertyCate", "postViews", "postImagesOne"])->where('disable', '0')->whereHas("propertyCate", function ($query) use ($purpose, $type) {
            $query->where("purpose", $purpose)->where("property_type", $type);
        });
        $post = $allpost->orderBy('post_boaster', 'DESC')->latest('created_at')->paginate(6);
        return $post;
    }



    public function agencyView()
    {

        $recordExistsOrNot = Agencie::where("user_id", Auth::id())->first();
        $cities = DB::table("city_and_areas")->distinct()->get("city");
        $check = true;
        //dd($recordExistsOrNot);
        if (!empty($recordExistsOrNot)) {
            //  dd("asd");
            return view("adminPanel.agency", compact("check", "recordExistsOrNot", "cities"));
        }
        return view("adminPanel.agency", compact("cities"));
    }

    public function agencyAdd(Request $req)
    {

        if ($req->exists('check')) {

            $req->validate([
                "name" => ['required'],
                "address" => ['required'],
                "image" => ['required'],
                'description' => ['required'],



            ]);

            ///delete old image
            $agency = Agencie::where("user_id", Auth::id())->first();

            //dd(public_path() . "/" . $agency);
            if (file_exists(public_path() . "/" . $agency->logo)) {
                unlink($agency->logo);
            }

            $path = $req->file('image')->store("agencyLogo", "public_main");

            $agency->name = $req->name;
            $agency->address = $req->address;
            $agency->logo = $path;
            $agency->city = $req->city;
            $agency->description = $req->description;
            $agency->save();

            return back()->with("success", "successfully record edited");
        }

        //////for add new agency first time
        $path = $req->file('image')->store("agencyLogo", "public_main");
        //dd($path);

        Agencie::create([

            "name" => $req->name,
            "address" => $req->address,
            "logo" => $path,
            "city" => $req->city,

            "user_id" => Auth::id(),
            'description' => $req->description,



        ]);
        return back()->with("success", "successfully record added");
    }


    public function addPostViews($user_id, $post_id)
    {
        if (Auth::check()) {
            PostViews::firstOrCreate(["user_id" => $user_id, "post_id" => $post_id]);
        }
    }

    public function verificationView()
    {

        $codeNumber = $this->sendCodeToMobile();

        PhoneNumberVarification::updateOrCreate(
            ["user_id" => Auth::id()],

            [
                "code" => $codeNumber,
                "verified" => 0
            ]

        );



        $userNumber = User::where("id", Auth::id())->first();
        $userNumber = $userNumber->mobile_number;

        return view('adminPanel.smsVerification', compact('userNumber'));
    }

    public function sendCodeToMobile($signUpMobileNo = null)

    {;
        $username = '923248430329';
        $password = "umair786";
        $reciverMobile = ($signUpMobileNo) ? $signUpMobileNo : Auth::user()->mobile_number;
        // dd($reciverMobile);
        //$reciverMobile = "923064389204";
        $sender = "SYED ZAMEEN";


        $randomNumber = rand(1000, 9999);
        $message = "Phone confirmation code '" . $randomNumber . "'  SYED ZAMEEN ";



        //dd($randomNumber);
        $response = Http::asForm()->post("https://sendpk.com/api/sms.php", [
            "username" => $username,
            "password" => $password,
            "sender" => $sender,
            "mobile" => $reciverMobile,
            "message" => $message


        ]);

        //$randomNumber = rand(1000, 9999);

        return $randomNumber;
    }

    public function finalizePhone(Request $req)
    {

        $phone = PhoneNumberVarification::where("user_id", Auth::id())
            ->where("code", $req->code)
            ->first();
        if (!empty($phone)) {
            if ($phone->verified == 1) {
                return redirect(route("dashbored"))->with("msg", "phone number is already verified");
            }

            $phone->verified = 1;
            $phone->save();
            $msg = "Phone number is succesfully verified ";
        } else {
            $msg = "code is incorrect , check your phone for new code ";
            return back()->with("msg", $msg);
        }

        return redirect(route('dashbored'))->with("msg", $msg);
    }



    public function numberView()
    {
        return view("smsVerification-change-phone");
    }


    public function changeNumber(Request $req)
    {       ////check for existing mobile number except current user/////
        $checkForExistingMobile = User::where("mobile_number", $req->phone)
            ->where("id", '!=', Auth::id())
            ->first();

        if (empty($checkForExistingMobile)) {
            $user = User::where("id", Auth::id())->first();
            $user->mobile_number = $req->phone;
            $user->save();
            $userPhone = $user->getPhone()->first();
            $userPhone->verified = 0;
            $userPhone->save();

            return $this->verificationView();
        }

        return back()->with("msg", "Phone number already exist");
    }



    public function getProperty($property)
    {

        $property = PropertyCategorie::where("property_type", $property)
            ->distinct()
            ->get('property_sub_type');

        return $property;
    }


    public function signupView()
    {


        return view('signup');
    }


    public function forgotPasswordView($diffView = "forgotView")
    {
        ///below variable is created  for changing view without creating new file

        $view = $diffView;
        return   view("forgot-password", compact("view"));
    }

    public function forgotPasswordPost(Request $req)
    {

        $req->validate(['number' => 'required']);





        $user = User::where("mobile_number", $req->number)->first();

        if (!empty($user)) {

            $code = $this->sendCodeToMobile($req->number);

            forgotPassword::updateOrCreate(
                ["user_id" => $user->id],
                ["code" => $code]
            );
            /////below variable used for the purpose of
            //changing view without creating another file with the help of if else
            $enterCode = "";

            $userID = $user->id;
            return view("forgot-password", compact("enterCode", "userID"));
        } else {
            $msg = "no account found associated with this mobile number ";

            return redirect()->back()->with('msg', $msg);
        }
    }


    public function forgotFinalPost(Request $req)
    {

        $userCodeConfirm = forgotPassword::where("user_id", $req->userID)
            ->where("code", $req->code)
            ->first();

        //dd($req->code, $req->userID);
        Session::put("user_id", $req->userID);

        $userID = $req->userID;

        if (!empty($userCodeConfirm)) {
            /////user authicattion confirm here know we change his password///
            $user = User::find($req->userID);

            Auth::login($user);
            $phoneVerified = PhoneNumberVarification::where("user_id", $req->userID)->first();
            $phoneVerified->verified = 1;
            $phoneVerified->save();

            Session::forget("user_id");

            $newpassword = 1;
            $token = rand(0, 100);
            session()->put("password", 0);
            return redirect(route("editProfile"))->with("newPassword", $newpassword);
        } else {
            $msg = "wrong code ";
            $enterCode = "";
            return view('forgot-password', compact(["userID", "msg", "enterCode"]));
        }
    }


    protected function newpassword(Request $req)
    {
        $passwordLength = strlen($req->password);

        if ($passwordLength > 4 && Session::has("password")) {

            $password = hash::make($req->password);
            $userID = Auth::id();
            $user = User::find($userID);
            $user->password = $password;
            $user->save();

            session()->forget("password");

            return back()->with("success", "Succesfully password changed");
        }

        return back()->with(["newPassword" => 1, "error" => "Password should be greater then 4"]);
    }

    //filteration
    public function propertySearch(Request $req)
    {

        $post = Post::with(["cityAndArea", "propertyCate", "postViews", "postImagesOne"])

            ->whereHas("propertyCate", function ($q) use ($req) {
                if ($req->purpose != "null" && $req->purpose != null) {
                    $q->where("purpose", $req->purpose);
                }

                if ($req->property_type != "null" && $req->property_type != null) {

                    $q->where("property_type", $req->property_type);
                }

                if ($req->sub_type != "null" && $req->sub_type != null) {

                    $q->where("property_sub_type", $req->sub_type);
                }
            }); ///closure exits

        if ($req->price != null && $req->price != "null") {

            $priceInArray = explode(";", $req->price);

            $post->whereBetween("price", $priceInArray);
        }
        //dd($req->area);
        if ($req->area != "null" && $req->area != null) {

            $areaInArray = explode(";", $req->area);

            $post->whereBetween("land_area", $areaInArray);
        }

        if ($req->beds != "null" && $req->beds != null) {
            //$areaInArray = explode(";", $req->area);
            $post->where("bedrooms", $req->beds);
        }


        if ($req->city != "null" && $req->city != null) {


            $post->whereHas("cityAndArea", function ($q) use ($req) {

                if ($req->cityAndArea != "null" &&  $req->cityAndArea != null) {
                    $q->where("id", $req->city_area);
                } else {

                    $q->where("city", $req->city);
                }
            });
        }

        //1=>normal
        //2=>hot
        //3=>superhot

        $allRCP = $post->orderBy('post_boaster', 'DESC')->latest('created_at')->paginate(6);







        $old_price = $req->price;
        $old_area = $req->area;
        $old_beds = $req->beds;
        $old_purpose = $req->purpose;

        $old_property_type = $req->property_type;
        //dd($req->sub_type);
        $old_property_sub_type = $req->sub_type;
        $searched = $req->search;
        $old_city = $req->city;
        $old_location = $req->city_area;
        //dd($old_area);

        $cities = DB::table("city_and_areas")->distinct()->get("city");


        return view("rent.commercial", compact(["old_location", "old_city", "cities", "searched", "allRCP", "old_price", "old_area", "old_beds", "old_purpose", "old_property_type", "old_property_sub_type"]));
    }





    public function searchAgency(Request $req)
    {


        $featureAgencies = new Agencie();

        if ($req->agency_name != "" && $req->agency_name != null) {
            //dd($req->agency_name);
            $featureAgencies = $featureAgencies->where("name", "LIKE", "%$req->agency_name%");
        }
        if ($req->city != "null" && $req->city != null) {
            $featureAgencies = $featureAgencies->where("city", $req->city);
        }

        $featureAgencies = $featureAgencies->paginate('3');

        //dd($featureAgencies);
        $latestPost = Post::with(["postImagesOne", "postViews", "propertyCate", "agencies", "favPostUser", "user"])
            ->where('admin_post', null)
            ->latest()
            ->limit(6)
            ->get();

        $cities = DB::table("city_and_areas")->distinct()->get("city");

        $old_agency_name = $req->agency_name;
        $old_city = $req->city;

        $favPost = AddToFavorite::where('user_id', Auth::id())->get();

        return view("agncies", compact("old_agency_name", "old_city", "featureAgencies", 'latestPost', "cities", "favPost"));
    }



    public function soldPost($postID)
    {

        $post = Post::where("id", "$postID")->where("user_id", Auth::id())->first();
        //dd($post->sold);
        if (!empty($post)) {

            if ($post->sold == "1") {
                $post->sold = 0;
            } else if ($post->sold == null  || $post->sold == "0") {
                //dd("when sold is null ");
                $post->sold = "1";
            }
            $post->save();
            return back()->with("succes", "succesfully changed the property status");
        }

        return "no post or user Associated with this command";
    }



    public function blogView()
    {

        return view("adminPanel.blog");
    }


    public function blog(Request $req)
    {


        $req->validateWithBag("blog_error", [
            "title" => "required",
            "content" => "required",
            "header" => "required"
        ]);

        if (count($req->images) > 3) {
            return back()->with("msg", "Only 3 photos are allowed");
        }

        $allValueFromRequest = $req->all("title", "content", "tags", "header");

        $allValueFromRequest["user_id"] = Auth::id();


        $blog = blog::create($allValueFromRequest);

        if (!empty($req->images)) {
            for ($i = 0; $i < count($req->images); $i++) {
                $imageName = Storage::disk("public_main")->put('blogImages', $req->images[$i]);

                $blogImage = blogImage::create([

                    "img_path" => $imageName,
                    "blog_id" => $blog->id

                ]);
            }
        }

        return back()->with("msg", "succesfully recored has been inserted");
    }


    public function blogMainView()
    {

        return view("blog");
    }


    public function blogEditView($id)
    {

        $blog = blog::find($id);

        if (!$blog) {
            abort(404);
        }
        ////following variable is used for switch the form between edit and add blog
        $editBlog = 1;

        //dd($blog);
        return view("adminPanel.blog", compact("blog", "editBlog"));
    }



    public function blogEdit(Request $req)
    {

        //dd($req->input());
        $blog = Blog::where("id", $req->blog_id)->first();

        $blog->title = $req->title;
        $blog->tags = $req->tags;
        $blog->content = $req->content;
        $blog->header = $req->header;

        if ($req->images != null) {
            ///delete old images
            $images = blogImage::where("blog_id", $blog->id)->get();

            foreach ($images as $image) {
                if (file_exists($image->img_path)) {
                    unlink($image->img_path);
                }
                $image->delete();
            }
            ///add new images

            for ($i = 0; $i < count($req->images); $i++) {

                $imageName = Storage::disk("public_main")->put('blogImages', $req->images[$i]);

                $blogImage = blogImage::create([

                    "img_path" => $imageName,
                    "blog_id" => $blog->id

                ]);
            }
        } //if end


        if ($blog->save()) {

            return redirect(route('blogAll'))->with("msg", "succesfully edited blog");
        }

        return back()->with("msg", "something went wrong");
    }



    public function blogAll()
    {
        $blogs = blog::with("blogImages")->get();
        //dd($blogs);
        return view("adminPanel.BlogDataTable", compact("blogs"));
    }

    public function deleteBlog($id)
    {
        $blog = Blog::with("blogImages")->where("id", $id)->first();

        foreach ($blog->blogImages as $image) {

            if (file_exists($image->img_path)) {
                unlink($image->img_path);
            }

            $image->delete();
        }

        $blog->delete();
        return back()->with("msg", "succesfully deleted the recored");
    }


    public function mainBlogView()
    {

        $blogs = blog::with("blogOneImage")->paginate(12);

        return view("blog", compact("blogs"));
    }

    public function blogMainSingleView($id)
    {
        $blog = blog::with("blogImages")->where("id", $id)->first();
        if (!$blog) {
            abort(404);
        }
        $blogs = blog::all();
        return view("blog-single-view", compact("blog", "blogs"));
    }
}
