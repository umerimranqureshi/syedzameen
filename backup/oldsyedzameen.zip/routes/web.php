<?php

use App\Http\Controllers\helper;
use App\Http\Controllers\mainAuth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\mainController;
use App\Http\Controllers\SecondMain;
use App\Http\Controllers\GoogleController;
use App\Models\blog;
use Illuminate\Foundation\Auth\EmailVerificationRequest;
use Illuminate\Http\Request;
use App\Models\PropertyCategorie;
use Facade\FlareClient\Stacktrace\File;
use Illuminate\Support\Facades\File as FacadesFile;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\ServiceProvider;
use App\Http\Controllers\ChatMessageController;
use App\Http\Controllers\FacebookLoginController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', [mainController::class, 'indexView'])->name('home');

Route::get('/login', [mainAuth::class, 'loginView']);
Route::post('/login', [mainAuth::class, 'login'])->name('login');

Route::get('/signup', [mainController::class, 'signupView'])->name('signup');

Route::get('/forgot', [mainController::class, 'forgotPasswordView'])->name('forgotView');
Route::post('/forgot/post', [mainController::class, 'forgotPasswordPost'])->name('forgotPost');
Route::post('/forgot/post/final', [mainController::class, 'forgotFinalPost'])->name('forgotFinalPost');

Route::post('/register', [mainAuth::class, 'register'])->name('register');


//Route::get('/email/verify', [mainAuth::class, "emailVerifyView"])->middleware(['auth'])->name('verification.notice');
Route::get('/email/verify', [mainAuth::class, "emailVerifyView"])->middleware(['auth'])->name('verification.notice');


Route::get('/email/verify/{id}/{hash}', [mainAuth::class, 'emailVerify'])->middleware(['auth', 'signed'])->name('verification.verify');


Route::post('/email/verification-notification', [mainAuth::class, "sendEmailVerifyLinkAgain"])->middleware(['auth', 'throttle:6,1'])->name('verification.send');

Route::get('/logout', [mainAuth::class, 'logout'])->name("logout");

Route::get('/rent/commercial', [mainController::class, 'rentCommercialView'])->name('rentCommercial');
Route::get('/rent/residential', [mainController::class, 'rentResidentialView'])->name('rentResidential');
Route::get('/sale/residential', [mainController::class, 'saleResidentialView'])->name('saleResidentail');
Route::get('/sale/commercial', [mainController::class, 'saleCommercialView'])->name('saleCommercial');

Route::get('/single/pageadd/{id}', [mainController::class, 'singlePageAddView'])->name("singlePage");

Route::get('/contact', [SecondMain::class, "contactUs"])->name('contactUs');










///////////////////every route which is only for Login user////////

Route::group(["middleware" => "auth"], function () {


        ///////////////////////////////////inbox routes////////////////////////////////
        Route::resource("inbox", ChatMessageController::class);
        Route::get("/conversation/{id}", [ChatMessageController::class, "conversationView"]);
        Route::get("/ajax/total/message/count", [ChatMessageController::class, "totalMessageCount"]);
        Route::get("/inboxNew", [ChatMessageController::class, "inboxNewView"]);


        /////////////////////Route Only for super admin come in following group///////////
        Route::group(['middleware' => 'superAdmin'], function () {

                Route::get('/admin/post', [SecondMain::class, 'adminFeaturePost'])->name('adminPost');
                Route::post('/admin/post', [SecondMain::class, 'adminPostAdd'])->name('addAdminPost');



                /////////write blog///////



                Route::get('/blog/view', [mainController::class, 'blogView'])->name("blogAdminView");
                Route::post("blog", [mainController::class, "blog"])->name("blog");
                Route::get("/blog/edit/{id}", [mainController::class, "blogEditView"])->name("blogMainView");
                Route::post("/blog/edit", [mainController::class, "blogEdit"])->name("blogEdit");
                Route::get("/blog/all", [mainController::class, "blogAll"])->name("blogAll");
                Route::get("/blog/delete/{id}", [mainController::class, "deleteBlog"])->name("deleteBlog");

                //admin delete or disable
                Route::get('delete/disable', [SecondMain::class, 'deleteDisableView'])->name('adminDeleteDisable');
                Route::get('admin/delete/{id}', [SecondMain::class, 'adminDeletePost'])->name('adminDelete');
                Route::get('admin/disable/enable{id}', [SecondMain::class, 'adminDisableEnable'])->name('adminDisable');

                //admin decides rates for freshes
                Route::get('/freshes/rates', [SecondMain::class, 'freshesView'])->name('freshesRatesView');
                Route::post('/freshes/rates', [SecondMain::class, 'addFreshesRates'])->name('addFreshesRates');
                Route::get('/fresh/edit/{id}', [SecondMain::class, 'editFreshView'])->name('editFreshView');
                Route::post('/fresh/edit/{id}', [SecondMain::class, 'updateFreshRate'])->name('updateRates');



                //coin request to admin
                Route::get('/coin/request', [SecondMain::class, 'allCoinRequest'])->name('allCoinRequest');
                //coin request to admin approved
                Route::get('/approve/coin/user/{user}/coin/{coins}/id{id}', [SecondMain::class, 'approveCoinRequest'])->name('approveCoin');
                //coins that admin approved
                Route::get('/approve/Requests', [Secondmain::class, 'showApprovedCoins'])->name('approvedCoinRequest');

                //post request to admin
                Route::get('/post/requests', [SecondMain::class, 'allPostrequests'])->name('allPostReq');
                //aprove req
                // Route::get('/post/request/{post_id}/boaster/{boaster_id}/category/{boaster_cat}/coins/{coins}/rupees/{rupees}/User/{user_id}', [SecondMain::class, 'allowBoasterPost'])->name('allowBoaster');

                //aproved request
                // Route::get('/approve/post/requests', [SecondMain::class, 'allApprovedPost'])->name('allApprovedPost');
                // Route::get('/coin/request', [SecondMain::class, 'allCoinRequest'])->name('allCoinRequest');
        });











        /////////////route which is only for sellers come here in below group////////
        Route::group(["middleware" => "sellerRoleCheck"], function () {
                Route::get('/post/add', [mainController::class, 'postAddView']);
                Route::post('/post/add', [mainController::class, 'postAdd']);

                Route::get('/all/post', [mainController::class, 'allPostView']);

                Route::get('/edit/post/{id}', [mainController::class, 'editPostView']);

                Route::post('/edit/post/{id}', [mainController::class, 'editPost']);


                Route::get('/delete/post/{id}', [mainController::class, 'deletePost']);

                Route::get('/agency', [mainController::class, 'agencyView'])->name("agency");
                Route::post('/agency', [mainController::class, 'agencyAdd'])->name("addAgency");

                ///pricing
                Route::get('/pricing', [SecondMain::class, 'pricingView'])->name('PricingView');
                Route::get('/coin/buy', [SecondMain::class, 'BuyCoinView'])->name('CoinBuy');
                ROute::post('/coin/buy/req', [SecondMain::class, 'addToRequestCoin'])->name('addCoins');

                //boast post
                Route::get('/boast/post/{post_id}/category/{cat}', [SecondMain::class, 'boastPost'])->name('boastPost');

                // Route::get('/pricing', [SecondMain::class, 'pricingView'])->name('PricingView');
                // Route::get('/coin/buy', [SecondMain::class, 'BuyCoinView'])->name('CoinBuy');
                // ROute::post('/coin/buy', [SecondMain::class, 'addToAccount'])->name('addCoinsAcc');

                //by coins

        });



        Route::get("verification/view", [mainController::class, "verificationView"])->name("verificationView");

        //////change phone enterd wrong phone//////
        Route::get("enter/phone/view", [mainController::class, "numberView"]);
        Route::post("enter/phone/view", [mainController::class, "changeNumber"]);
        //////change phone because entring wrong phone number end//////



        Route::post("verifyPhone", [mainController::class, "finalizePhone"])->name("finalPhone");

        Route::get('/edit/profile', [mainController::class, 'editProfileView'])->name('editProfile');

        Route::post('/edit/profile', [mainController::class, 'editProfileSubmit'])->name('editProfileSubmit');



        Route::post('/profile/photo', [mainController::class, 'uploadUserProfile'])->name('profilePhotoUpload');

        //Route::get('/areas', [mainController::class, 'getAllLahoreArea']);


        Route::get('/dashbored', [mainController::class, 'dashboredView'])->name('dashbored');



        //////sold post , method for check or uncheck post sale or not

        Route::get('/sold/post/{id}', [mainController::class, 'soldPost'])->name("sold");

        ///////////forgot password procedure final step after login, add new password method

        Route::post('/newpassword', [mainController::class, 'newpassword'])->name("newpassword");
});



Route::get('/areas/{city}', [mainController::class, 'getAreasAccordingCity']);



Route::get('/fav/post/add/{id}', [SecondMain::class, 'addToFav'])->name('favPost');
Route::get('/post/fav', [SecondMain::class, 'showFavPost'])->name('showFavPost');

//become a seller



Route::get('/moreinfo', [SecondMain::class, 'userMoreInfo'])->name('userMoreInfo');
Route::post('/moreinfo', [SecondMain::class, 'submitMoreInfo'])->name('submitMoreInfo');


/////////api for getting residential or commercial base specific proeprty///////

Route::get("get/property/{id}", [mainController::class, 'getProperty']);

/* Route::post('/agent/request/{id}', [SecondMain::class, 'addToRequestAgent'])->name('requestAnAgent');


Route::get('/agents/request', [SecondMain::class, 'showAllRequestToAgents'])->name('requestToAgenst');

Route::get('/client/request', [SecondMain::class, 'ShowClientrequest'])->name('showClientRequest');
 */
Route::get('/agencies', [SecondMain::class, 'showAgencies'])->name('showAgencies');


Route::get('/property/search', [mainController::class, 'propertySearch'])->name('property.search');

Route::get('/search/agency', [mainController::class, 'searchAgency'])->name('searchAgency');

//api for favPost red button

// Route::get('/fav/post/api', [SecondMain::class, 'favPostApi']);
//////blog route for public
Route::get('/blog/main/view', [mainController::class, 'mainBlogView'])->name("mainBlogView");
Route::get('/blog/main/single/view/{id}', [mainController::class, 'blogMainSingleView'])->name("blogMainSingleView");
Route::get('/edit/edit', [ChatMessageController::class, 'edit']);

//-----------------------------------login with facebook-------------------------------//

Route::get('auth/facebook', [FacebookLoginController::class, 'facebookRedirect']);
Route::get('auth/facebook/callback', [FacebookLoginController::class, 'loginWithFacebook']);


//----------------------google login----------------------//

Route::get('auth/google', [GoogleController::class,'redirectToGoogle'])->name('loginGoogle');
Route::get('auth/google/callback', [GoogleController::class,'handleGoogleCallback']);


//----------------------------single page agency-------------------------//
Route::get('single/agency/{id}',[SecondMain::class,'singlePageAgency'])->name('agencySinglePage');