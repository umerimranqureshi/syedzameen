<?php $__env->startSection('body'); ?>
<div class="error-page py-80" style="background: url(<?php echo e(asset('7.png')); ?>) no-repeat center right/45%; height: 100vh">
	<div class="container h-100">
		<div class="row h-100 align-items-center">
			<div class="col-lg-12">
				<div class="error-info text-center w-50">
					<h1 class="color-primary" style="font-size: 96px">404</h1>
					<h2 class="py-20 color-secondary">Opps! Page Not Found</h2>
					<p>The page you are looking for might have been removed Had its name changed
                        or its temporarily removed.
                    </p>
					<a class="btn btn-primary mt-30" href="<?php echo e(route('home')); ?>">Back to Home</a>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syedzameen\resources\views/errors/404.blade.php ENDPATH**/ ?>