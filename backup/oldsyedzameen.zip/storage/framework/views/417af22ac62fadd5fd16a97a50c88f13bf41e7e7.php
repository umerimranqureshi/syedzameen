<?php $helper = app('App\Http\Controllers\helper'); ?>



<?php $__env->startSection('header'); ?>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"
	integrity="sha256-4+XzXVhsDmqanXGHaHvgh1gMQKX40OUvDEBTu8JcmNs=" crossorigin="anonymous"></script>

<style>
	.icon-size {
		font-size: 20px;

	}

	.slider-table td,
	th {
		padding: 0px 16px;
		text-align: center;
	}

	.slider-table td+td {
		border-left: 1px solid;



	}

	.slider-icons {
		color: #ffffffda;
		font-size: 22px;
	}

	.slider-data {
		color: #ffffffda;

	}

	.slider-data-type {
		color: #ffffff56;
		font-size: 13px;
		font-weight: 200;
	}
</style>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('body'); ?>



<!-- Slider Start
=========================================================================-->
<div id="slider" style="height:1080px;margin:0 auto;margin-bottom: 0px;">

	<?php $__currentLoopData = $adminPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>




	<!-- Slide 1-->
	<div class="ls-slide"
		data-ls="bgsize:cover; bgposition:50% 50%; duration:4000; transition2d:5; kenburnsscale:1.2; parallaxtype:3d; parallaxdistance:4; parallaxrotate:20;">
		<img width="1920" height="1080" src="<?php echo e(asset('assets/images/slider/6.jpg')); ?>" class="ls-bg" alt="" />
		<img width="340" height="200" src="<?php echo e(asset('assets/images/slider/6.jpg')); ?>" class="ls-tn" alt="" />
		<div style="width:875px; height:410px; background:#ffffff; border-radius:0px; top:75px; left:20px;" class="ls-l"
			data-ls="offsetxin:-150; durationin:2000; easingin:easeOutExpo; rotateyin:-30; transformoriginin:50% 50% -300px; offsetxout:100; durationout:800; easingout:easeInExpo; rotateyout:30; transformoriginout:50% 50% -300px; parallax:true; parallaxlevel:20;">
		</div>

		<div style="text-align:center; width:100px; height:35px; line-height: 35px; font-family:'Roboto'; font-size:15px; color:#ffffff; border-radius:0px; top:58px; left:66px;"
			class="ls-l bg-primary"
			data-ls="delayin:2000; easingin:easeOutElastic; rotateyin:-300; durationout:400; rotateyout:-400; parallaxlevel:0;">
			<?php echo e($post->propertyCate->purpose); ?></div>
		<p style="font-weight:700;letter-spacing:-0.03em;font-family:Montserrat; font-size:30px; line-height:36px; color:#242424; top:121px; left:66px;"
			class="ls-l"
			data-ls="offsetxin:-150; durationin:2000; easingin:easeOutExpo; rotateyin:-30; transformoriginin:78.2% 416.7% -700px; offsetxout:100; durationout:800; easingout:easeInExpo; rotateyout:30; transformoriginout:78.2% 416.7% -700px; parallax:true; parallaxlevel:35;">
			<?php echo e($post->property_title); ?></p>
		<p style="font-weight:700; letter-spacing:-0.03em;font-family:Montserrat; font-size:24px; line-height:36px; color:#fd9834; top:177px; left:66px;"
			class="ls-l"
			data-ls="offsetxin:-150; durationin:2000; easingin:easeOutExpo; rotateyin:-30; transformoriginin:270.5% 275% -600px; offsetxout:100; durationout:800; easingout:easeInExpo; rotateyout:30; transformoriginout:270.5% 275% -600px; parallax:true; parallaxlevel:30;">
			PKR <?php echo e($helper::labelWithAmount($post->price)); ?></p>
		<p style="font-weight:400;width:310px; font-family:Roboto; font-size:14px; line-height:24px; color:#666666; top:235px; left:69px; white-space:normal;"
			class="ls-l"
			data-ls="offsetxin:-150; durationin:2000; easingin:easeOutExpo; rotateyin:-30; transformoriginin:124.7% 32.5% -500px; offsetxout:100; durationout:800; easingout:easeInExpo; rotateyout:30; transformoriginout:124.7% 32.5% -500px; parallax:true; parallaxlevel:25;">
			<?php echo e($post->description); ?>.</p>
		<p style="font-weight:400;cursor:pointer; letter-spacing: 1px; padding-right:30px; padding-left:30px; font-family:Montserrat; font-size:16px; line-height:50px; color:#ffffff; background:#fd9834; border-radius:0px; top:385px; left:66px;"
			class="ls-l"
			data-ls="offsetxin:-150; durationin:2000; easingin:easeOutExpo; rotateyin:-30; transformoriginin:199.2% -244.4% -600px; offsetxout:100; durationout:800; easingout:easeInExpo; rotateyout:30; transformoriginout:199.2% -244.4% -600px; hover:true; hoverdurationin:300; hoveropacity:1; hoverbgcolor:#ffa319; parallax:true; parallaxlevel:30;">

			<a style="text-decoration: none;color:white" href="<?php echo e(route('singlePage',['id'=>$post->id])); ?>"> View Details
			</a></p>

		<?php if($post->postImages->count()>0): ?>
		<?php if(count($post->postImages)>=1): ?>
		<a href="<?php echo e(route('singlePage',['id'=>$post->id])); ?>">
			<img width="618" height="304" src="<?php echo e(asset('propertyImages/'.$post->postImages[0]->img_path)); ?>" class="ls-l"
				alt="" style="top:205px; left:374px;"
				data-ls="offsetxin:-150; durationin:2000; easingin:easeOutExpo; rotateyin:-30; transformoriginin:13.2% 24.3% -1000px; offsetxout:100; durationout:800; easingout:easeInExpo; rotateyout:30; transformoriginout:13.2% 24.3% -1000px; parallax:true; parallaxlevel:50;">
		</a>
		<?php endif; ?>
		<a style="" class="ls-l" href="<?php echo e(route('singlePage',['id'=>$post->id])); ?>" target="_self"
			data-ls="offsetxin:-150; durationin:2000; easingin:easeOutExpo; rotateyin:-30; transformoriginin:-185.1% 134.1% -1400px; offsetxout:100; durationout:800; easingout:easeInExpo; rotateyout:30; transformoriginout:-185.1% 134.1% -1400px; hover:true; hoveropacity:1; hoverscalex:0.95; hoverscaley:0.95; parallax:true; parallaxlevel:70;">
			<?php if(count($post->postImages)>=2): ?>
			<img width="185" height="185" src="<?php echo e(asset('propertyImages/'.$post->postImages[1]->img_path)); ?>"
				class=" ls-imagelightbox" alt="" style="border-radius:50%; top:31px; left:798px;">
			<?php endif; ?>
		</a>

		<a style="" class="ls-l" href="<?php echo e(route('singlePage',['id'=>$post->id])); ?>" target="_self"
			data-ls="offsetxin:-150; durationin:2000; easingin:easeOutExpo; rotateyin:-30; transformoriginin:-149.2% 170.4% -1200px; offsetxout:100; durationout:800; easingout:easeInExpo; rotateyout:30; transformoriginout:-149.2% 170.4% -1200px; hover:true; hoveropacity:1; hoverscalex:0.95; hoverscaley:0.95; parallax:true; parallaxlevel:60;">
			<?php if(count($post->postImages)>=3): ?>
			<img width="125" height="125" src="<?php echo e(asset('propertyImages/'.$post->postImages[2]->img_path)); ?>"
				class=" ls-imagelightbox" alt="" style="border-radius:50%; top:66px; left:642px;">
			<?php endif; ?>
		</a>
		<?php else: ?>
		<img width="618" height="304" src="<?php echo e(asset('houseLog.jpg')); ?>" class="ls-l" alt="" style="top:205px; left:374px;"
			data-ls="offsetxin:-150; durationin:2000; easingin:easeOutExpo; rotateyin:-30; transformoriginin:13.2% 24.3% -1000px; offsetxout:100; durationout:800; easingout:easeInExpo; rotateyout:30; transformoriginout:13.2% 24.3% -1000px; parallax:true; parallaxlevel:50;">
		<?php endif; ?>
		<div width="800" height="173" class="ls-l ls-hide-phone ls-hide-tablet" alt=""
			style="width:283px; top:503px; left:25px;"
			data-ls="offsetyin:-100; durationin:1500; delayin:1000; easingin:easeOutExpo; durationout:400; easingout:easeInOutQuad; parallax:true; parallaxlevel:9;">
			<table class="slider-table">
				<tr class="slider-icons">
					<th><i class="fa fa-plus-square "></i></th>
					<th><i class="fa fa-bed"></i></th>
					<th><i class="fa fa-bath"></i></th>
					<th><i class="fa fa-home"></i></th>
				</tr>
				<tr class="slider-data">
					<td><?php echo e($post->land_area); ?></td>
					<td>0<?php echo e($post->bedrooms); ?></td>
					<td>0<?php echo e($post->bathrooms); ?></td>
					<td>01</td>
				</tr>
				<tr class="slider-data-type">
					<td>Marla</td>
					<td>Bedrooms</td>
					<td>Bathrooms</td>
					<td>Garage</td>
				</tr>
			</table>
		</div>
	</div>

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>

<!-- Slider End
=========================================================================-->
<!-- Feautred Properties Start
=========================================================================-->
<section class="featured-properties bg-light">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="main-title w-75 mx-auto d-table text-center mb-30">
					<span class="small-title color-primary position-relative line-2-primary">Find Out the Best
						One</span>

					<h2 class="title mb-20 color-secondary">Lastest added Properties</h2>
					<span class="sub-title">Check out our Latest Properties section. Here you can find out
						the latest six properties.
					</span>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="owl-carousel slide-3 owl-nav-side owl-dots-none mt-30 owl-loaded owl-drag"
					id="refresh-loop">

					<?php $__currentLoopData = $latestPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $postt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



					<div class="property-item">

						<div class="property-img position-relative overflow-hidden overlay-secondary-4">
							<img style="height:300px "
								src="<?php echo e($postt->postImagesOne?asset('propertyImages/'.$postt->postImagesOne->img_path):asset('houseLog.jpg')); ?>"
								alt="image">

							<!-------if post is sold then show below element------>
							<?php if($postt->sold=="1"): ?>

							<div style="position: absolute;width:100%;text-align:center;top:40%">
								<h1 style="color:white">SOLD</h1>
							</div>

							<?php endif; ?>



							<span
								class="thum-category category-1 bg-secondary color-white z-index-1 px-15 headings-post">
								<?php echo e($postt->propertyCate->purpose); ?>

								<?php if($postt->post_boaster=='hot' ||  $postt->post_boaster=='superhot'): ?>
												<i class="fa fa fa-fire px-1" 
												style="color:<?php echo e(($postt->post_boaster=='superhot')?'red':'rgb(255, 0, 234)'); ?>"
												></i>
												<?php endif; ?>
							</span>
							<span style="margin-left: -15px"
								class="thum-category category-2 bg-secondary color-white z-index-1 px-15 headings-post">Featured</span>
								<?php if($postt->post_boaster=='superhot' || $postt->post_boaster=='hot'): ?>
								<span style="margin-left:85px;background-color:<?php echo e(($postt->post_boaster=='superhot')?'rgba(216, 71, 71, 0.877)':'rgba(94, 54, 54, 0.897)'); ?>"
								class="thum-category category-2  color-white z-index-1 px-15 ">
								
							
							
								<?php echo e(($postt->post_boaster=='superhot')?'Super Hot':'Hot'); ?>

								
							</span>
							<?php endif; ?>
								
							<ul class="hover-option position-absolute icon-white z-index-1">
								<li>

									<a data-toggle="tooltip" data-placement="top" <?php $__currentLoopData = $favPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($fav->user_id==Auth::id() && $postt->favPostUser->count()>0 &&
										$fav->post_id==$postt->id): ?>
										class="bg-danger fav-heart "
										title="remove wishlist"


										<?php endif; ?>

										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php if($postt->favUserPost==null && Auth::check()): ?>
										class="fav-heart headings-post"
										title="wishlist"
										<?php endif; ?>

										href="<?php echo e(route('favPost',['id'=>$postt->id])); ?>" >
										<i class="fa fa-heart-o heart" aria-hidden="true"> </i></a>
								</li>



							</ul>



							<div class="meta-property icon-primary color-white z-index-1">
								<ul>
									<li><i class="fa fa-calendar"></i> <?php echo e($postt->created_at->diffForHumans()); ?></li>
									
									<li><i class="fa fa-user"></i><?php echo e($postt->user->name); ?> </li>
								</ul>
							</div>
						</div>
						<div class="property-content bg-white pt-30 pb-50 px-30">

							<a class="color-secondary mb-5" style="word-break: break-all"
								href="<?php echo e(route('singlePage',["id" => "$postt->id"])); ?>">
								<h4 id="for-lenght" style="line-height: 30px;height:61px"><?php echo e($postt->property_title); ?>.
								</h4>

								<span class="address icon-primary f-14" style="height: 60px"><i
										class="fa fa-map-marker"></i><?php echo e($postt->address); ?>.</span>
								<ul class="about-property list-half icon-primary d-table f-14 mb-30 mt-20">

									<li><i
											class="fa fa-plus-square icon-size"></i><?php echo e($postt->land_area." ". $postt->unit); ?>

										Marla</li>
									<li><i class="fa fa-bed icon-size"></i><?php echo e($postt->bedrooms); ?> Bedrooms</li>
									<li><i class="fa fa-bath icon-size"></i><?php echo e($postt->bathrooms); ?> Bathrooms</li>
									<li><i class="fa fa-home icon-size"></i>Garage</li>
									<li><i style="font-size: 17px;" class="fa fa-eye" aria-hidden="true"></i>
										<?php echo e(" ".count($postt->postViews)." "); ?>views</li>

								</ul>
								<div class="property-cost color-white list-half w-100">
									<ul>
										<li><?php echo e($postt->propertyCate->purpose); ?></li>
										<li style="font-size:14px">PKR : <?php echo e(" ".$helper::labelWithAmount($postt->price)); ?> <sub>
												</sub></li>
									</ul>
								</div>
							</a>
						</div>
					</div>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>





				</div>
			</div>
		</div>
	</div>
</section>
<!-- Feautred Properties End
=========================================================================-->



<!-- Why Choose Us Start
=========================================================================-->
<section class="position-relative" style="background: url(images/background/1.png) no-repeat bottom center / cover;">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-lg-7">
				<div class="bg-white p-50">
					<div class="row">
						<div class="col-md-10 col-lg-10">
							<div class="side-title mb-30">
								<span class="small-title color-primary position-relative line-primary">Want A Better
									Life?</span>
								<h2 class="title mb-20 color-secondary">Buy A Property and Lead A Happy Life.</h2>
								<p>Owning a home is one of the most common financial goals in the Pakistan,
									and there are many reasons why. It’s a source of stability,
									it gives you control, it allows you to build equity,
									it reflects your style, and on some level,
									it’s associated with a feeling of success.</p>
							</div>
							<div class="why-us mt-30 flat-medium icon-primary">
								<ul>
									<li>
										<span class="float-left mr-15"><i style="font-size:40px"
												class="fa fa-bed"></i></span>
										<div class="d-table">
											<h4 class="color-secondary mb-15">Location of the House</h4>
											<p>Location is key to valuable real estate.
												Homes in cities that have little room for expansion tend to be
												more valuable than those in cities that have plenty of room..</p>
										</div>
									</li>
									<li class="mt-30">
										<span class="float-left mr-15"><i style="font-size: 40px"
												class="fa fa-car"></i></span>
										<div class="d-table">
											<h4 class="color-secondary mb-15">Parking Lot Size</h4>
											<p>The average size of a parking space is 320 square feet. However, there
												are also other sizes available,
												one of the most common of which is 270 square feet.
												These sizes include the landscaping or end of aisle areas,
												the circulation areas and the parking space. .</p>
										</div>
									</li>
									<li class="mt-30">
										<span class="float-left mr-15"><i style="font-size:40px"
												class="fa fa-home"></i></span>
										<div class="d-table">
											<h4 class="color-secondary mb-15">Age of the House</h4>
											<p>A house is a concrete structure made of other earthly elements that are
												bound to deteriorate over time.
												Moreover, extreme weather,
												environmental conditions and rigorous usage, damage the structure in its
												own way..</p>
										</div>
									</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="w-100">
				<div class="fact-counter achievement text-center py-50 px-30 position-absolute bg-secondary">
					<div class="row">
						<div class="col-md-6 col-lg-6">
							<div class="counter count wow">
								<div class="counter-point d-inline-block">
									<h2 class="count-num color-primary" data-speed="3000"
										data-stop="<?php echo e($allPostNumber); ?>"></h2>
								</div>
								<h6 class="achievement-title color-white">Properties Listed</h6>
							</div>
						</div>
						<div class="col-md-6 col-lg-6">
							<div class="counter count wow mt-sm-30">
								<div class="counter-point d-inline-block">
									<h2 class="count-num color-primary" data-speed="3000" data-stop="500"></h2>
								</div>
								<h6 class="achievement-title color-white">Locations Covers</h6>
							</div>
						</div>
						<div class="col-md-6 col-lg-6">
							<div class="counter count wow mt-30">
								<div class="counter-point d-inline-block">
									<h2 class="count-num color-primary" data-speed="3000"
										data-stop="<?php echo e($allAgentNumber); ?>">0</h2>
								</div>
								<h6 class="achievement-title color-white">Expert Agents</h6>
							</div>
						</div>
						<div class="col-md-6 col-lg-6">
							<div class="counter count wow mt-30">
								<div class="counter-point d-inline-block">
									<h2 class="count-num color-primary" data-speed="3000"
										data-stop="<?php echo e($allSoldProperty); ?>">0</h2>
								</div>
								<h6 class="achievement-title color-white">Properties Sold</h6>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section>
<!-- Why Choose Us Start
=========================================================================-->

<!-- Best Offer Start
=========================================================================-->
<section>
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-lg-12">
				<div class="main-title w-75 mx-auto d-table text-center mb-30">
					<span class="small-title color-primary position-relative line-2-primary">Hot Property</span>
					<h2 class="title mb-20 color-secondary">Best Offers of This Week</h2>
					<span class="sub-title">Here are some best offers you may get just look at it what you want.</span>
				</div>
			</div>
			<?php
			$i=0;
			$p=$specialPost;
			?>
			<div class="col-md-12 col-lg-12 col-xl-8">
				<div class="row">
					<?php if(array_key_exists($i, $p)): ?>
					<div class="col-md-12 col-lg-7">
						<div class="property-thumbnail mt-30">
							<div class="property-img position-relative overflow-hidden overlay-secondary-4">

								<img src="<?php echo e($p[$i]->postImagesOne?asset('propertyImages/'.$p[$i]->postImagesOne->img_path):asset('houseLog.jpg')); ?>"
									alt="image" style="height: 288px">
									<?php if($p[$i]->sold=="1"): ?>

										<div style="position: absolute;width:100%;text-align:center;top:40%">
											<h1 style="color:white">SOLD</h1>
										</div>

										<?php endif; ?>

								<div class="thumbnail-content z-index-1 color-white-a color-white">
									<span
												class="thum-category category-1 bg-secondary color-white z-index-1 px-15 headings-post">For
												<?php echo e($p[$i]->propertyCate->purpose); ?>

												<?php if($p[$i]->post_boaster=='hot' ||  $p[$i]->post_boaster=='superhot'): ?>
												<i class="fa fa fa-fire px-1" 
												style="color:<?php echo e(($p[$i]->post_boaster=='superhot')?'red':'rgb(255, 0, 234)'); ?>"
												></i>
												<?php endif; ?>
											</span>
									<ul class="hover-option position-absolute icon-white z-index-1">
										<li>
											<a data-toggle="tooltip" data-placement="top" <?php $__currentLoopData = $favPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($fav->user_id==Auth::id() && $p[$i]->favPostUser->count()>0 &&
												$fav->post_id==$p[$i]->id): ?>
												class="bg-danger fav-heart"
												title="remove wishlist"


												<?php endif; ?>

												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php if($p[$i]->favUserPost==null && Auth::check()): ?>
												class="fav-heart headings-post"
												title="wishlist"
												<?php endif; ?>

												href="<?php echo e(route('favPost',['id'=>$p[$i]->id])); ?>">
												<i class="fa fa-heart-o" aria-hidden="true"></i>
											</a>
										</li>

									</ul>
									<div class="hover-content py-30 px-20 overlay-hover-gradient">
										<div class="thumbnail-title z-index-1 position-relative">
													<?php if($p[$i]->post_boaster=='superhot' || $p[$i]->post_boaster=='hot'): ?>
													<span
													class="thumbnail-price px-15 mb-10 d-table" style="background-color:<?php echo e(($p[$i]->post_boaster=='superhot')?'rgba(216, 71, 71, 0.877)':'rgba(94, 54, 54, 0.897)'); ?>" >
												
													<?php echo e(($p[$i]->post_boaster=='superhot')?'Super Hot':'Hot'); ?></span>
													<?php endif; ?>
											<span
												class="thumbnail-price bg-white color-secondary px-15 mb-10 d-table">PKR:
												<?php echo e($p[$i]->price); ?><?php echo e($p[$i]->propertyCate->purpose=="(rent)"?'(Monthly)':''); ?></span>
											<a class="color-secondary mb-5 "
												href="<?php echo e(route('singlePage',['id'=>$p[$i]->id])); ?>">
												<h4><?php echo e($p[$i]->property_title); ?> </h4>
											</a>
											<span class="address icon-primary f-14"><i
													class="fa fa-map-marker"></i><?php echo e($p[$i]->address); ?> </span>
										</div>
										<ul
											class="about-property icon-primary d-table f-14 z-index-1 position-relative">
											<li><i
													class="fa fa-plus-square icon-size"></i><?php echo e($p[$i]->land_area." ". $p[$i]->unit); ?>

												Marla</li>
											<li><i class="fa fa-bed icon-size"></i><?php echo e($p[$i]->bedrooms); ?></li>
											<li><i class="fa fa-bath icon-size"></i> <?php echo e($p[$i]->bathrooms); ?></li>
											<li><i class="fa fa-home icon-size"></i>1</li>
											<li><i style="font-size: 17px;" class="fa fa-eye" aria-hidden="true"></i>
												<?php echo e(count($p[$i]->postViews)); ?> views</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php endif; ?>

					<?php if(array_key_exists($i+1, $p)): ?>
					<div class="col-md-12 col-lg-5">
						<div class="property-thumbnail mt-30">
							<div class="property-img position-relative overflow-hidden overlay-secondary-4">
								<img src="<?php echo e($p[$i+1]->postImagesOne?asset('propertyImages/'.$p[$i+1]->postImagesOne->img_path):asset('houseLog.jpg')); ?>"
									alt="image" style="height: 288px">
									<?php if($p[$i+1]->sold=="1"): ?>

									<div style="position: absolute;width:100%;text-align:center;top:40%">
										<h1 style="color:white">SOLD</h1>
									</div>

									<?php endif; ?>
								<div class="thumbnail-content z-index-1 color-white-a color-white">
									<span
										class="thum-category category-1 bg-secondary color-white z-index-1 px-15 d-table headings-post">For
										<?php echo e($p[$i+1]->propertyCate->purpose); ?>

										<?php if($p[$i+1]->post_boaster=='hot' ||  $p[$i+1]->post_boaster=='superhot'): ?>
										<i class="fa fa fa-fire px-1" 
										style="color:<?php echo e(($p[$i+1]->post_boaster=='superhot')?'red':'rgb(255, 0, 234)'); ?>"
										></i>
										<?php endif; ?>
									</span>
									<ul class="hover-option position-absolute icon-white z-index-1">
										<li>
											<a data-toggle="tooltip" data-placement="top" <?php $__currentLoopData = $favPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($fav->user_id==Auth::id() && $p[$i+1]->favPostUser->count()>0 &&
												$fav->post_id==$p[$i+1]->id): ?>
												class="bg-danger fav-heart"
												title="remove wishlist"


												<?php endif; ?>

												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php if($p[$i+1]->favUserPost==null && Auth::check()): ?>
												class="fav-heart headings-post"
												title="wishlist"
												<?php endif; ?>

												href="<?php echo e(route('favPost',['id'=>$p[$i+1]->id])); ?>">
												<i class="fa fa-heart-o" aria-hidden="true"></i>
											</a>

										</li>

									</ul>
									<div class="hover-content py-30 px-20 overlay-hover-gradient">
										<div class="thumbnail-title z-index-1 position-relative">
											<?php if($p[$i+1]->post_boaster=='superhot' || $p[$i+1]->post_boaster=='hot'): ?>
											<span 
											class="thumbnail-price px-15 mb-10 d-table" style="margin-left: 115px;background-color:<?php echo e(($p[$i+1]->post_boaster=='superhot')?'rgba(216, 71, 71, 0.877)':'rgba(94, 54, 54, 0.897)'); ?>" >
										
											<?php echo e(($p[$i+1]->post_boaster=='superhot')?'Super Hot':'Hot'); ?></span>
											<?php endif; ?>
											<span class="thumbnail-price bg-white color-secondary px-15 mb-10">PKR:
												<?php echo e($p[$i+1]->price); ?></span>
											<a class="color-secondary mb-5"
												href="<?php echo e(route('singlePage',['id'=>$p[$i]->id])); ?>">
												<h4><?php echo e($p[$i+1]->property_title); ?> </h4>
											</a>
											<span class="address icon-primary f-14"><i
													class="fa fa-map-marker"></i><?php echo e($p[$i+1]->address); ?></span>
										</div>
										<ul
											class="about-property icon-primary d-table f-14 z-index-1 position-relative">
											<li><i
													class="fa fa-plus-square icon-size"></i><?php echo e($p[$i+1]->land_area." ". $p[$i+1]->unit); ?>

												Marla</li>
											<li><i class="fa fa-bed icon-size"></i><?php echo e($p[$i+1]->bedrooms); ?></li>
											<li><i class="fa fa-bath icon-size"></i> <?php echo e($p[$i+1]->bathrooms); ?></li>
											<li><i class="fa fa-home icon-size"></i>1</li>
											<li><i style="font-size: 17px;" class="fa fa-eye" aria-hidden="true"></i>
												<?php echo e(count($p[$i+1]->postViews)); ?> views</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php endif; ?>

					<?php if(array_key_exists($i+2, $p)): ?>
					<div class="col-md-12 col-lg-5">
						<div class="property-thumbnail mt-30">
							<div class="property-img position-relative overflow-hidden overlay-secondary-4">
								<img src="<?php echo e($p[$i+2]->postImagesOne?asset('propertyImages/'.$p[$i+2]->postImagesOne->img_path):asset('houseLog.jpg')); ?>"
									alt="image" style="height: 315px">
									<?php if($p[$i+2]->sold=="1"): ?>

									<div style="position: absolute;width:100%;text-align:center;top:40%">
										<h1 style="color:white">SOLD</h1>
									</div>

									<?php endif; ?>
								<div class="thumbnail-content z-index-1 color-white-a color-white">
									<span
										class="thum-category category-1 bg-secondary color-white z-index-1 px-15 d-table headings-post">For
										<?php echo e($p[$i+2]->propertyCate->purpose); ?>

										<?php if($p[$i+2]->post_boaster=='hot' ||  $p[$i+2]->post_boaster=='superhot'): ?>
										<i class="fa fa fa-fire px-1" 
										style="color:<?php echo e(($p[$i+2]->post_boaster=='superhot')?'red':'rgb(255, 0, 234)'); ?>"
										></i>
										<?php endif; ?>
									</span>
									<ul class="hover-option position-absolute icon-white z-index-1">
										<li>
											<a data-toggle="tooltip" data-placement="top" <?php $__currentLoopData = $favPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($fav->user_id==Auth::id() && $p[$i+2]->favPostUser->count()>0 &&
												$fav->post_id==$p[$i+2]->id): ?>
												class="bg-danger fav-heart"
												title="remove wishlist"


												<?php endif; ?>

												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php if($p[$i+2]->favUserPost==null && Auth::check()): ?>
												class="fav-heart headings-post"
												title="wishlist"
												<?php endif; ?>

												href="<?php echo e(route('favPost',['id'=>$p[$i+2]->id])); ?>">
												<i class="fa fa-heart-o" aria-hidden="true"></i>
											</a>

										</li>

									</ul>
									<div class="hover-content py-30 px-20 overlay-hover-gradient">
										<div class="thumbnail-title z-index-1 position-relative">
											<?php if($p[$i+2]->post_boaster=='superhot' || $p[$i+2]->post_boaster=='hot'): ?>
											<span
											class="thumbnail-price px-15 mb-10 d-table" style="background-color:<?php echo e(($p[$i+2]->post_boaster=='superhot')?'rgba(216, 71, 71, 0.877)':'rgba(94, 54, 54, 0.897)'); ?>" >
										
											<?php echo e(($p[$i+2]->post_boaster=='superhot')?'Super Hot':'Hot'); ?></span>
											<?php endif; ?>
											<span
												class="thumbnail-price bg-white color-secondary px-15 mb-10 d-table">PKR:
												<?php echo e($p[$i+2]->price); ?></span>
											<a class="color-secondary mb-5"
												href="<?php echo e(route('singlePage',['id'=>$p[$i+2]->id])); ?>">
												<h4><?php echo e($p[$i+2]->property_title); ?></h4>
											</a>
											<span class="address icon-primary f-14"><i
													class="fa fa-map-marker"></i><?php echo e($p[$i+2]->address); ?></span>
										</div>
										<ul
											class="about-property icon-primary d-table f-14 z-index-1 position-relative">
											<li><i
													class="fa fa-plus-square icon-size"></i><?php echo e($p[$i+2]->land_area." ". $p[$i+2]->unit); ?>

												Marla</li>
											<li><i class="fa fa-bed icon-size"></i><?php echo e($p[$i+2]->bedrooms); ?></li>
											<li><i class="fa fa-bath icon-size"></i> <?php echo e($p[$i+2]->bathrooms); ?></li>
											<li><i class="fa fa-home icon-size"></i>1</li>
											<li><i style="font-size: 17px;" class="fa fa-eye" aria-hidden="true"></i>
												<?php echo e(count($p[$i+2]->postViews)); ?> views</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php endif; ?>

					<?php if(array_key_exists($i+3, $p)): ?>
					<div class="col-md-12 col-lg-7">
						<div class="property-thumbnail mt-30">
							<div class="property-img position-relative overflow-hidden overlay-secondary-4">
								<img src="<?php echo e($p[$i+3]->postImagesOne?asset('propertyImages/'.$p[$i+3]->postImagesOne->img_path):asset('houseLog.jpg')); ?>"
									alt="image" style="height: 315px">
									<?php if($p[$i+3]->sold=="1"): ?>

									<div style="position: absolute;width:100%;text-align:center;top:40%">
										<h1 style="color:white">SOLD</h1>
									</div>

									<?php endif; ?>
								<div class="thumbnail-content z-index-1 color-white-a color-white">
									<span
										class="thum-category category-1 bg-secondary color-white z-index-1 px-15 d-table headings-post">For
										<?php echo e($p[$i+3]->propertyCate->purpose); ?>

										<?php if($p[$i+3]->post_boaster=='hot' ||  $p[$i+3]->post_boaster=='superhot'): ?>
										<i class="fa fa fa-fire px-1" 
										style="color:<?php echo e(($p[$i+3]->post_boaster=='superhot')?'red':'rgb(255, 0, 234)'); ?>"
										></i>
										<?php endif; ?></span>
									<ul class="hover-option position-absolute icon-white z-index-1">
										<li>
											<a data-toggle="tooltip" data-placement="top" <?php $__currentLoopData = $favPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($fav->user_id==Auth::id() && $p[$i+3]->favPostUser->count()>0 &&
												$fav->post_id==$p[$i+3]->id): ?>
												class="bg-danger fav-heart"
												title="remove wishlist"


												<?php endif; ?>

												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												<?php if($p[$i+3]->favUserPost==null && Auth::check()): ?>
												class="fav-heart headings-post"
												title="wishlist"
												<?php endif; ?>

												href="<?php echo e(route('favPost',['id'=>$p[$i+3]->id])); ?>">
												<i class="fa fa-heart-o" aria-hidden="true"></i>
											</a>

										</li>

									</ul>
									<div class="hover-content py-30 px-20 overlay-hover-gradient">
										<div class="thumbnail-title z-index-1 position-relative">
											<?php if($p[$i+3]->post_boaster=='superhot' || $p[$i+3]->post_boaster=='hot'): ?>
											<span
											class="thumbnail-price px-15 mb-10 d-table" style="background-color:<?php echo e(($p[$i+3]->post_boaster=='superhot')?'rgba(216, 71, 71, 0.877)':'rgba(94, 54, 54, 0.897)'); ?>" >
										
											<?php echo e(($p[$i+3]->post_boaster=='superhot')?'Super Hot':'Hot'); ?></span>
											<?php endif; ?>
											<span
												class="thumbnail-price bg-white color-secondary px-15 mb-10 d-table">PKR:
												<?php echo e($p[$i+3]->price); ?></span>
											<a class="color-secondary mb-5"
												href="<?php echo e(route('singlePage',['id'=>$p[$i+3]->id])); ?>">
												<h4><?php echo e($p[$i+3]->property_title); ?></h4>
											</a>
											<span class="address icon-primary f-14"><i
													class="fa fa-map-marker"></i><?php echo e($p[$i+3]->address); ?></span>
										</div>
										<ul
											class="about-property icon-primary d-table f-14 z-index-1 position-relative">
											<li><i
													class="fa fa-plus-square icon-size"></i><?php echo e($p[$i+3]->land_area." ". $p[$i+3]->unit); ?>

												Marla</li>
											<li><i class="fa fa-bed icon-size"></i><?php echo e($p[$i+3]->bedrooms); ?></li>
											<li><i class="fa fa-bath icon-size"></i> <?php echo e($p[$i+3]->bathrooms); ?></li>
											<li><i class="fa fa-home icon-size"></i>1</li>
											<li><i style="font-size: 17px;" class="fa fa-eye" aria-hidden="true"></i>
												<?php echo e(count($p[$i+3]->postViews)); ?> views</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
					<?php endif; ?>
				</div>
			</div>

			<?php if(array_key_exists($i+4, $p)): ?>
			<div class="col-md-12 d-none-lg col-xl-4">
				<div class="property-thumbnail mt-30">
					<div class="property-img position-relative overflow-hidden overlay-secondary-4">
						<img src="<?php echo e($p[$i+4]->postImagesOne?asset('propertyImages/'.$p[$i+4]->postImagesOne->img_path):asset('houseLog.jpg')); ?>"
							alt="image" style="height: 634px">
							<?php if($p[$i+4]->sold=="1"): ?>

							<div style="position: absolute;width:100%;text-align:center;top:40%">
								<h1 style="color:white">SOLD</h1>
							</div>

							<?php endif; ?>
						<div class="thumbnail-content z-index-1 color-white-a color-white">
							<span
								class="thum-category category-1 bg-secondary color-white z-index-1 px-15 d-table headings-post">For
								<?php echo e($p[$i+4]->propertyCate->purpose); ?>

								<?php if($p[$i+4]->post_boaster=='hot' ||  $p[$i+4]->post_boaster=='superhot'): ?>
										<i class="fa fa fa-fire px-1" 
										style="color:<?php echo e(($p[$i+4]->post_boaster=='superhot')?'red':'rgb(255, 0, 234)'); ?>"
										></i>
										<?php endif; ?>
							</span>
							<ul class="hover-option position-absolute icon-white z-index-1">
								<li>
									<a data-toggle="tooltip" data-placement="top" <?php $__currentLoopData = $favPost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fav): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<?php if($fav->user_id==Auth::id() && $p[$i+4]->favPostUser->count()>0 &&
										$fav->post_id==$p[$i+4]->id): ?>
										class="bg-danger fav-heart"
										title="remove wishlist"


										<?php endif; ?>

										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php if($p[$i+4]->favUserPost==null && Auth::check()): ?>
										class="fav-heart headings-post"
										title="wishlist"
										<?php endif; ?>

										href="<?php echo e(route('favPost',['id'=>$p[$i+4]->id])); ?>">
										<i class="fa fa-heart-o" aria-hidden="true"></i>
									</a>

								</li>

							</ul>
							<div class="hover-content py-30 px-20 overlay-hover-gradient">
								<div class="thumbnail-title pb-15 z-index-1 position-relative">
									<?php if($p[$i+4]->post_boaster=='superhot' || $p[$i+4]->post_boaster=='hot'): ?>
											<span
											class="thumbnail-price px-15 mb-10 d-table" style="background-color:<?php echo e(($p[$i+4]->post_boaster=='superhot')?'rgba(216, 71, 71, 0.877)':'rgba(94, 54, 54, 0.897)'); ?>" >
										
											<?php echo e(($p[$i+4]->post_boaster=='superhot')?'Super Hot':'Hot'); ?></span>
											<?php endif; ?>
									<span class="thumbnail-price bg-white color-secondary px-15 mb-10 d-table">PKR:
										<?php echo e($p[$i+4]->price); ?></span>
									<a class="color-secondary mb-5" href="<?php echo e(route('singlePage',['id'=>$p[$i+4]->id])); ?>">
										<h4><?php echo e($p[$i+4]->property_title); ?></h4>
									</a>
									<span class="address icon-primary f-14"><i
											class="fa fa-map-marker"></i><?php echo e($p[$i+4]->address); ?></span>
								</div>
								<ul class="about-property icon-primary d-table f-14 z-index-1 position-relative">
									<li><i
											class="fa fa-plus-square icon-size"></i><?php echo e($p[$i+4]->land_area." ". $p[$i+4]->unit); ?>

										Marla</li>
									<li><i class="fa fa-bed icon-size"></i><?php echo e($p[$i+4]->bedrooms); ?></li>
									<li><i class="fa fa-bath icon-size"></i> <?php echo e($p[$i+4]->bathrooms); ?></li>
									<li><i class="fa fa-home icon-size"></i>1</li>
									<li><i style="font-size: 17px;" class="fa fa-eye" aria-hidden="true"></i>
										<?php echo e(count($p[$i+4]->postViews)); ?> views</li>
								</ul>
							</div>
						</div>
					</div>
				</div>
			</div>
			<?php endif; ?>
		</div>
	</div>
</section>
<!-- Best Offer End
=========================================================================-->


<!-- Our Agents Two Start
==================================================================-->
<section class="agent-style-2">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-lg-5">
				<div class="side-title mb-30">
					<span class="small-title color-primary position-relative line-primary">Team</span>
					<h2 class="title mb-20 color-secondary">Our Most Popular Agencies</h2>
					<p>Are you looking for a new website for your growing real estate business?
						Do you need help building your social media presence to start selling more homes and making more
						connections?
						We've analyzed agencies across Pakistan that specialize in real estate marketing to help you
						find a marketing partner you can trust.
						Considering that over 92% of homebuyers now use the internet to shop for houses,
						making your real estate business stand out online is a must for success.
						Check out our list of real estate marketing agencies here!.</p>
				</div>
			</div>
			<div class="col-md-12 col-lg-7">
				<div class="owl-carousel slide-6">

					<?php $__currentLoopData = $featureAgencies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



					<div class="agent-profile">
						<div class="overflow-hidden"><img src="<?php echo e($agency->logo?asset($agency->logo):''); ?>" alt="image">
						</div>
						<div class="agent-profile-content hover-secondery-primary py-20 px-15 bg-white">
							<a class="mb-5 d-block" href="#">
								<h5><?php echo e($agency->name); ?></h5>
							</a>
							<span class="color-gray"></span>
							<a class="btn-round bg-secondary" href="#"><i class="fa fa-angle-right"></i></a>
						</div>
					</div>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



				</div>
			</div>
		</div>
	</div>
</section>
<!-- Our Agents Two End
==================================================================-->
<!-- Testimonial Start
=========================================================================-->

<!-- Blog End
=========================================================================-->
<!--  Partners and Subscribe Form Start
=========================================================================-->
<div class="patner-subscribe">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-lg-12">
				<div class="bg-white shadow py-80">
					<div class="row">
						<div class="col-md-12 col-lg-6 px-60 border-right">
							<div class="side-title pb-30">
								<span class="small-title color-primary position-relative line-primary">Partners</span>
								<h2 class="title mb-20 color-secondary">Our Brands!</h2>
								<p>Syed Zameen By SYED REAL ESTATE .
									Syed zameen is a project of SYED REAL ESATAE ,
									Syed Real Estates and builders is the largest full-service real estate and property
									management company , They known for their quanlity work .

									.</p>
							</div>
							<div class="owl-carousel partners mt-30">
								<img src="<?php echo e(asset('login-logo.png')); ?>" alt="Image not found!">
								<img src="<?php echo e(asset('syedEstate Real logo.png')); ?>" alt="">

							</div>
						</div>
						<div class="col-md-12 col-lg-6 px-60">
							<div class="side-title pb-30 text-right mt-md-50">
								<span
									class="small-title color-primary position-relative line-right-primary">Newsletter</span>
								<h2 class="title mb-20 color-secondary">Get Update Now!</h2>
								<p>Wait a bit ! before leaving add your email we will notify you about new property and
									much more .</p>
							</div>
							<form class="news-letter bg-gray mt-30">
								<div id="subscribe-message" style="margin-bottom:2px;font-size:20px"></div>
								<div class="form-group position-relative" id="subscribe-hide">
									<input class="form-control" type="text" name="email" placeholder="Subscribe"
										id="subscribe-input">
									<button class="bg-gray color-secondary" id="btn-subscribe"><i
											class="fa fa-paper-plane"></i></button>
								</div>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<script>
	// $("#post-id").hide();
			// console.log(	$("#post-id").val())

		// console.log($(".heart"));


	$(document).ready(()=>{

		// $('#snipper').hide();

		$(document).on('click', '.fav-heart', function(e) {
	e.preventDefault();


	var data = $(this).attr('href');

	var self = this;
  // Save the reference
        $.ajax({
            method: 'get',
            url: data,
            data: data,
            async: true,

            success: ()=>{
                // console.log(data);
				// $(self).data('disabled','disabled');


				console.log("success");

            },
			complete: (data)=> {
				if(data.responseJSON.message=="remove") {
						self.classList.remove("bg-danger");
						self.classList.add("headings-post");
						setTimeout(()=>{
							$(this).tooltip('hide').attr('data-original-title', 'wishlist');
						},500);
						console.log("class removes");
					}else if((data.responseJSON.message=="success")){
						self.classList.add("bg-danger");
						setTimeout(()=>{
							$(this).tooltip('hide').attr('data-original-title', 'remove wishlist');
						},500);

					}else{
						console.log("no classs applied");
					}


     		}

		});

});
$("#subscribe-input").on("input", function(){
        // Print entered value in a div box

			if(!$(this).val()){

				$('#subscribe-message').text('email required');
		$('#subscribe-message').css('color','red');

			}else{
				$('#subscribe-message').text('');
			}

    });
$(document).on('click', '#btn-subscribe', function(e) {
	e.preventDefault();
	if($('#subscribe-input').val()==''){
		$('#subscribe-message').text('email required');
		$('#subscribe-message').css('color','red');
	}else{


	$('#subscribe-hide').hide();
	$('#subscribe-message').text('Thanks for subscribing us');
	$('#subscribe-message').addClass('color-primary');

	}
});


	});


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\syedzameen\resources\views/index.blade.php ENDPATH**/ ?>